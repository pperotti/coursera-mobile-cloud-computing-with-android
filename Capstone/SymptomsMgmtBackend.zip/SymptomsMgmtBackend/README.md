# Symptoms Management Backend

## Overview

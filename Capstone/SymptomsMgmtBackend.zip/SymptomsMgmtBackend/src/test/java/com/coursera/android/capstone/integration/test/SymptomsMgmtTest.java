package com.coursera.android.capstone.integration.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Collection;
import java.util.List;

import org.junit.Test;

import retrofit.RetrofitError;
import retrofit.client.ApacheClient;

import com.coursera.android.capstone.client.SecuredRestBuilder;
import com.coursera.android.capstone.client.SymptomMgmtApi;
import com.coursera.android.capstone.data.About;
import com.coursera.android.capstone.data.CheckIn;
import com.coursera.android.capstone.data.Doctor;
import com.coursera.android.capstone.data.Medicine;
import com.coursera.android.capstone.data.Patient;
import com.coursera.android.capstone.data.Profile;
import com.coursera.android.capstone.data.Question;
import com.coursera.android.capstone.data.Reminder;
import com.coursera.android.capstone.data.Response;
import com.coursera.android.capstone.data.Role;

/**
 * A test for the Asgn2 video service
 * 
 * @author mitchell
 */
public class SymptomsMgmtTest {

	private final String TEST_URL = "https://localhost:8443";

	private final String DOCTOR1 = "0001-00000001";
	private final String DOCTOR2 = "0001-00000002";
	private final String PATIENT1 = "0002-00000001";
	private final String CHECKINID = "12345678";
	private final String PASSWORD = "pass";
	private final String CLIENT_ID = "mobile";

	private SymptomMgmtApi patientSvcClient = new SecuredRestBuilder()
			.setClient(new ApacheClient(UnsafeHttpsClient.createUnsafeClient()))
			.setEndpoint(TEST_URL)
			.setLoginEndpoint(TEST_URL + SymptomMgmtApi.TOKEN_PATH)
			.setUsername(PATIENT1).setPassword(PASSWORD).setClientId(CLIENT_ID)
			.build().create(SymptomMgmtApi.class);

	private SymptomMgmtApi doctorSvcClient = new SecuredRestBuilder()
			.setClient(new ApacheClient(UnsafeHttpsClient.createUnsafeClient()))
			.setEndpoint(TEST_URL)
			.setLoginEndpoint(TEST_URL + SymptomMgmtApi.TOKEN_PATH)
			.setUsername(DOCTOR1).setPassword(PASSWORD).setClientId(CLIENT_ID)
			.build().create(SymptomMgmtApi.class);

	// Check authentication as a doctor
	@Test
	public void testGetAuthenticationAsDoctor() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		About about = doctorSvcClient.getAbout();
		assertNotNull(about);
	}

	// Check authentication as a patient
	@Test
	public void testGetAuthenticationAsPatient() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		About about = patientSvcClient.getAbout();
		assertNotNull(about);
	}

	@Test
	public void testGetAuthenticationAsStrange() {
		try {
			SymptomMgmtApi invalidUserSvcClient = new SecuredRestBuilder()
					.setClient(
							new ApacheClient(UnsafeHttpsClient
									.createUnsafeClient()))
					.setEndpoint(TEST_URL)
					.setLoginEndpoint(TEST_URL + SymptomMgmtApi.TOKEN_PATH)
					.setUsername("abcdef").setPassword(PASSWORD)
					.setClientId(CLIENT_ID).build()
					.create(SymptomMgmtApi.class);

			invalidUserSvcClient.getAbout();
			fail();
		} catch (Exception e) {
			if (e instanceof RetrofitError) {
				// Success
			} else {
				fail();
			}

		}
	}

	@Test
	public void testGetPatientsForAValidDoctor() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		Collection<Patient> patients = doctorSvcClient.getPatients(DOCTOR1);
		assertNotNull(patients);
		assertEquals(4, patients.size());

		patients = doctorSvcClient.getPatients(DOCTOR2);
		assertNotNull(patients);
		assertEquals(6, patients.size());

		try {
			patients = doctorSvcClient.getPatients("");
		} catch (RetrofitError re) {
			assertEquals(404, re.getResponse().getStatus());
		}
	}

	@Test
	public void testGetPatientsForAnInvalidDoctor() {
		assertTrue(doctorSvcClient.postInitTestData());
		try {
			Collection<Patient> patients = doctorSvcClient
					.getPatients("123456");
			assertNotNull(patients);
		} catch (RetrofitError re) {
			assertEquals(404, re.getResponse().getStatus());
		}
	}

	@Test
	public void testGetDoctorsProfile() {
		assertTrue(doctorSvcClient.postInitTestData());
		try {
			Profile profile = doctorSvcClient.getDoctorProfile(DOCTOR1);
			assertNotNull(profile);
		} catch (RetrofitError re) {
			fail();
		}
	}

	@Test
	public void testGetPatientProfile() {
		assertTrue(patientSvcClient.postInitTestData());
		try {
			Profile profile = patientSvcClient.getPatientProfile(PATIENT1);
			assertNotNull(profile);
		} catch (RetrofitError re) {
			fail();
		}
	}

	@Test
	public void testGetPatientReminder() {
		assertTrue(patientSvcClient.postInitTestData());
		try {
			Reminder reminder = patientSvcClient.getPatientReminder(PATIENT1);
			assertNotNull(reminder);
		} catch (RetrofitError re) {
			fail();
		}
	}
	
	@Test
	public void testGetPatientMedicines() {
		assertTrue(patientSvcClient.postInitTestData());
		try {
			List<Medicine> medicines = patientSvcClient.getPatientMedicines(PATIENT1);
			assertNotNull(medicines);
			assertEquals(3, medicines.size());
		} catch (RetrofitError re) {
			fail();
		}
	}
	
	@Test
	public void testGetMedicines() {
		assertTrue(doctorSvcClient.postInitTestData());
		try {
			Collection<Medicine> medicines = doctorSvcClient.getMedicines();
			assertNotNull(medicines);
			assertEquals(3, medicines.size());
		} catch (RetrofitError re) {
			fail();
		}
	}

	@Test
	public void testGetQuestions() {
		assertTrue(doctorSvcClient.postInitTestData());
		try {
			List<Question> questions = doctorSvcClient.getQuestions();
			assertNotNull(questions);
			assertEquals(4, questions.size());
		} catch (RetrofitError re) {
			fail();
		}
	}
	
	@Test
	public void testGetPatientQuestions() {
		assertTrue(patientSvcClient.postInitTestData());
		try {
			List<Question> questions = patientSvcClient.getPatientQuestions(PATIENT1);
			assertNotNull(questions);
			assertEquals(4, questions.size());
		} catch (RetrofitError re) {
			fail();
		}
	}

	@Test
	public void testGetPatientCheckIns() {
		assertTrue(patientSvcClient.postInitTestData());
		try {
			Collection<CheckIn> checkIns = patientSvcClient.getPatientCheckIns(PATIENT1);
			assertNotNull(checkIns);
		} catch (RetrofitError re) {
			fail();
		}
	}
	
	@Test
	public void testGetPatientCheckInById() {
		assertTrue(patientSvcClient.postInitTestData());
		try {
			List<Response> responses = patientSvcClient.getPatientCheckInResponses(PATIENT1, CHECKINID);
			assertNotNull(responses);
		} catch (RetrofitError re) {
			fail();
		}
	}
	
	@Test
	public void testPostPatientProfile() {
		assertTrue(patientSvcClient.postInitTestData());
		
		Profile newProfile = new Profile();
		newProfile.setEmail("newEmail@gmail.com").setName("new name").setLastName("new lastname");
		
		Patient patient = patientSvcClient.postPatientProfile(PATIENT1, newProfile);
		Profile updatedProfile = patient.getProfile();
		assertEquals(newProfile.getEmail(), updatedProfile.getEmail());
		assertEquals(newProfile.getName(), updatedProfile.getName());
		assertEquals(newProfile.getLastName(), updatedProfile.getLastName());
	}
	
	@Test
	public void testPostDoctorProfile() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		Profile newProfile = new Profile();
		newProfile.setEmail("newEmail@gmail.com").setName("new name").setLastName("new lastname");
		
		Doctor doctor = doctorSvcClient.postDoctorProfile(DOCTOR1, newProfile);
		Profile updatedProfile = doctor.getProfile();
		assertEquals(newProfile.getEmail(), updatedProfile.getEmail());
		assertEquals(newProfile.getName(), updatedProfile.getName());
		assertEquals(newProfile.getLastName(), updatedProfile.getLastName());
	}
	
	@Test
	public void testPostPatientCheckIn() {
		assertTrue(patientSvcClient.postInitTestData());
		CheckIn c = new CheckIn();
		c.addResponse(new Response("new question", "new response"));
		Patient patient = patientSvcClient.postPatientCheckIn(PATIENT1, c);
		assertNotNull(patient.getCheckIns());
		System.out.println("\n\n\n\n->" + patient.getCheckIns());
		assertEquals(2, patient.getCheckIns().size());
	}
	
	@Test
	public void testPostPatientReminder() {
		assertTrue(patientSvcClient.postInitTestData());
		
		Reminder reminder = new Reminder().setFrequency(2).setMessage("It's checkIn Time!");
		Patient updatedPatient = patientSvcClient.postPatientReminder(PATIENT1, reminder);
		assertNotNull(updatedPatient);
		Reminder updatedReminder = updatedPatient.getReminder();
		assertEquals(2, updatedReminder.getFrequency());
		assertEquals("It's checkIn Time!", updatedReminder.getMessage());
	}
	
	@Test
	public void testPostPatientMedicine() {
		assertTrue(patientSvcClient.postInitTestData());
		
		List<Medicine> originalMedicines = patientSvcClient.getPatientMedicines(PATIENT1);
		
		Medicine newMedicine = new Medicine("New Medicine");
		Patient updatedPatient = patientSvcClient.postPatientMedicine(PATIENT1, newMedicine);
		
		assertNotNull(updatedPatient);
		assertNotNull(updatedPatient.getMedicines());
		assertEquals(originalMedicines.size()+1, updatedPatient.getMedicines().size());
	}
	
	@Test
	public void testPostMedicine() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		Collection<Medicine> originalMedicines = doctorSvcClient.getMedicines();
		
		Medicine newMedicine = new Medicine("New Medicine");
		Collection<Medicine> updatedMedicines = doctorSvcClient.postMedicine(newMedicine);
		
		assertNotNull(updatedMedicines);
		assertEquals(originalMedicines.size()+1, updatedMedicines.size());
		
		Collection<Medicine> afterNewUpdateMedicines = doctorSvcClient.postMedicine(newMedicine);
		assertEquals(updatedMedicines.size(), afterNewUpdateMedicines.size());
	}
	
	@Test
	public void testDeleteMedicine() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		Collection<Medicine> originalMedicines = doctorSvcClient.getMedicines();
		
		Collection<Medicine> updatedMedicines = doctorSvcClient.deleteMedicine("m1");
		
		assertNotNull(updatedMedicines);
		assertEquals(originalMedicines.size()-1, updatedMedicines.size());
	}
	
	@Test
	public void testDeletePatientMedicine() {
		assertTrue(doctorSvcClient.postInitTestData());
				
		Patient patient = doctorSvcClient.deletePatientMedicine(PATIENT1, "m1");
		
		assertNotNull(patient);
		assertEquals(2, patient.getMedicines().size());
	}
	
	@Test
	public void testPostNewQuestion() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		List<Question> currentQuestions = doctorSvcClient.getQuestions();
		
		Question question = new Question("New Question");
		Collection<Question> newQuestions = doctorSvcClient.postQuestion(question);
		assertEquals(currentQuestions.size()+1, newQuestions.size());
	}
	
	@Test
	public void testPostPatientQuestion() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		List<Question> currentQuestions = doctorSvcClient.getQuestions();
		
		Question question = new Question("New Question");
		Patient patient = doctorSvcClient.postPatientQuestion(PATIENT1, question);
		assertEquals(currentQuestions.size()+1, patient.getQuestions().size());
	}
	
	@Test
	public void testGetDoctorRole() {
		assertTrue(doctorSvcClient.postInitTestData());
		
		Role role = doctorSvcClient.getRole("0001-00000001");
		assertEquals(Role.ROLE_DOCTOR, role.getName());
	}
	
	@Test
	public void testGetPatientRole() {
		assertTrue(patientSvcClient.postInitTestData());
		
		Role role = patientSvcClient.getRole("0002-00000001");
		assertEquals(Role.ROLE_PATIENT, role.getName());
	}
	
	@Test
	public void testGetInvalidRole() {
		assertTrue(patientSvcClient.postInitTestData());
		try {
			patientSvcClient.getRole("ffff");
			fail();
		} catch (RetrofitError re) { 
			assertEquals(404, re.getResponse().getStatus());
		}
	}
}

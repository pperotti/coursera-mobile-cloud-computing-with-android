package com.coursera.android.capstone.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Patient's data
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 */
public class Patient {

	Profile profile;
	List<CheckIn> checkIns = new ArrayList<CheckIn>();
	Reminder reminder;
	List<Medicine> medicines = new ArrayList<Medicine>();
	List<Question> questions = new ArrayList<Question>();

	public Patient(Profile profile) {
		this.profile = profile;
	}
	
	public Profile getProfile() {
		return this.profile;
	}

	public Patient setProfile(Profile profile) {
		this.profile = profile;
		return this;
	}

	public Reminder getReminder() {
		return this.reminder;
	}

	public Patient setReminder(Reminder reminder) {
		this.reminder = reminder;
		return this;
	}

	public List<Medicine> getMedicines() {
		return this.medicines;
	}
	
	public Patient setMedicines(List<Medicine> medicines) {
		this.medicines = medicines;
		return this;
	}

	public Patient addMedicine(Medicine medicine) {
		this.medicines.add(medicine);
		return this;
	}

	public Patient removeMedicine(Medicine medicine) {
		this.medicines.remove(medicine);
		return this;
	}

	public Patient addQuestion(Question question) {
		this.questions.add(question);
		return this;
	}

	public Patient removeQuestion(Question question) {
		this.questions.remove(question);
		return this;
	}

	public List<Question> getQuestions() {
		return this.questions;
	}

	public List<CheckIn> getCheckIns() {
		return this.checkIns;
	}

	public CheckIn getCheckIn(String checkInId) {
		Iterator<CheckIn> iterator = checkIns.iterator();
		while ( iterator.hasNext() ) {
			CheckIn ci = iterator.next();
			if ( ci.getTimestamp().equals(checkInId) ) {
				return ci;
			}
		}
		return null;
	}

	public Patient addCheckIn(CheckIn checkIn) {
		if (checkIn != null) {
			checkIns.add(checkIn);
		}
		return this;
	}
}

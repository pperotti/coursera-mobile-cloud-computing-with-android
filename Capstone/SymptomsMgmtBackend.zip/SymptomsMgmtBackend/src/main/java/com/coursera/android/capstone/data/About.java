package com.coursera.android.capstone.data;

public class About {
	private String mMessage;
	
	public About(String message) {
		mMessage = message;
	}
	
	public void setMessage(String message) {
		mMessage = message;
	}
	
	public String getMessage() {
		return mMessage;
	}
}

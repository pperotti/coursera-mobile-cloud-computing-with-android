package com.coursera.android.capstone.data;

import java.util.ArrayList;
import java.util.List;

/**
 * All the information related with one particular check-in.
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 */
public class CheckIn {

	private String timestamp;
	private List<Response> responses;
	
	public CheckIn() {
		responses = new ArrayList<Response>();
		timestamp = String.valueOf(System.currentTimeMillis());
	}
	
	public CheckIn setTimestamp(String timestamp) {
		this.timestamp = timestamp;
		return this;
	}
	
	public List<Response> getResponses() {
		return this.responses;
	}
	
	public void setResponses(List<Response> responses) {
		this.responses = responses;
	}
	
	public CheckIn addResponse(Response response) {
		responses.add(response);
		return this;
	}
	
	public String getTimestamp() {
		return this.timestamp;
	}
}

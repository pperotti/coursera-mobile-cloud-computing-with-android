package com.coursera.android.capstone.client;

import java.util.Collection;
import java.util.List;

import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Path;

import com.coursera.android.capstone.data.About;
import com.coursera.android.capstone.data.CheckIn;
import com.coursera.android.capstone.data.Doctor;
import com.coursera.android.capstone.data.Medicine;
import com.coursera.android.capstone.data.Patient;
import com.coursera.android.capstone.data.Profile;
import com.coursera.android.capstone.data.Question;
import com.coursera.android.capstone.data.Reminder;
import com.coursera.android.capstone.data.Response;
import com.coursera.android.capstone.data.Role;

/**
 * Retrofit API interface
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 */
public interface SymptomMgmtApi {

	public static final String TITLE_PARAMETER = "title";

	public static final String DURATION_PARAMETER = "duration";

	public static final String TOKEN_PATH = "/oauth/token";

	// Path for all the available
	public static final String PATH_ABOUT = "/about";
	public static final String PATH_DOCTOR = "/doctor";
	public static final String PATH_PATIENT = "/patient";
	public static final String PATH_PROFILE = "/profile";
	public static final String PATH_REMINDER = "/reminder";
	public static final String PATH_MEDICINE = "/medicine";
	public static final String PATH_QUESTION = "/question";
	public static final String PATH_ANSWER = "/answer";
	public static final String PATH_CHECKIN = "/checkin";
	public static final String PATH_RESPONSE = "/response";
	public static final String PATH_INITTESTDATA = "/initTestData";
	public static final String PATH_ROLE = "/role";

	@GET(PATH_ABOUT)
	public About getAbout();

	@GET(PATH_DOCTOR + "/{id}" + PATH_PATIENT)
	public Collection<Patient> getPatients(@Path("id") String id);

	@GET(PATH_DOCTOR + "/{id}" + PATH_PROFILE)
	public Profile getDoctorProfile(@Path("id") String id);

	@GET(PATH_PATIENT + "/{id}" + PATH_PROFILE)
	public Profile getPatientProfile(@Path("id") String id);

	@GET(PATH_PATIENT + "/{id}" + PATH_REMINDER)
	public Reminder getPatientReminder(@Path("id") String id);

	@GET(PATH_PATIENT + "/{id}" + PATH_MEDICINE)
	public List<Medicine> getPatientMedicines(@Path("id") String id);

	@GET(PATH_MEDICINE)
	public Collection<Medicine> getMedicines();

	@GET(PATH_QUESTION)
	public List<Question> getQuestions();

	@GET(PATH_PATIENT + "/{id}" + PATH_QUESTION)
	public List<Question> getPatientQuestions(@Path("id") String id);

	@GET(PATH_PATIENT + "/{id}" + PATH_CHECKIN)
	public Collection<CheckIn> getPatientCheckIns(@Path("id") String id);

	@GET(PATH_PATIENT + "/{id}" + PATH_CHECKIN + "/{checkInId}" + PATH_RESPONSE)
	public List<Response> getPatientCheckInResponses(
			@Path("id") String patientId, @Path("checkInId") String checkInId);
	
	@POST(PATH_INITTESTDATA)
	public Boolean postInitTestData();
	
	@POST(PATH_PATIENT + "/{id}" + PATH_PROFILE)
	public Patient postPatientProfile(@Path("id") String id, @Body Profile profile);
	
	@POST(PATH_DOCTOR + "/{id}" + PATH_PROFILE)
	public Doctor postDoctorProfile(@Path("id") String id, @Body Profile profile);
	
	@POST(PATH_PATIENT + "/{id}" + PATH_CHECKIN)
	public Patient postPatientCheckIn(@Path("id") String id, @Body CheckIn checkin);
	
	@POST(PATH_PATIENT + "/{id}" + PATH_REMINDER)
	public Patient postPatientReminder(@Path("id") String id, @Body Reminder reminder);
	
	@POST(PATH_PATIENT + "/{id}" + PATH_MEDICINE)
	public Patient postPatientMedicine(@Path("id") String id, @Body Medicine medicine);
	
	@POST(PATH_MEDICINE)
	public Collection<Medicine> postMedicine(@Body Medicine medicine);
	
	@DELETE(PATH_MEDICINE + "/{id}")
	public Collection<Medicine> deleteMedicine(@Path("id") String id);
	
	@DELETE(PATH_PATIENT + "/{id}" + PATH_MEDICINE + "/{medicineId}")
	public Patient deletePatientMedicine(@Path("id") String id, @Path("medicineId") String medicineId);
	
	@POST(PATH_QUESTION)
	public List<Question> postQuestion(@Body Question question);
	
	@POST(PATH_PATIENT + "/{id}" + PATH_QUESTION)
	public Patient postPatientQuestion(@Path("id") String id, @Body Question question);
	
	@GET(PATH_ROLE + "/{id}")
	public Role getRole(@Path("id") String id);


}

package com.coursera.android.capstone.data;

/**
 * Represent one possible answer to a question. 
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 */
public class Answer {
	
	private String text;
	
	public Answer(String text) {
		this.text = text;
	}
	
	public String getText() {
		return this.text;
	}
	
	public Answer setText(String text) {
		this.text = text;
		return this;
	}
}

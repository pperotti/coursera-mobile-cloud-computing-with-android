package com.coursera.android.capstone.data;

import java.util.ArrayList;
import java.util.List;

/**
 * Represent custom question that a doctor can create for one or more patient.
 * 
 * One particular question will have more than possible answers.
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 */
public class Question {

	private String text;

	private List<Answer> answers;
	
	public Question() {
		
	}
	
	public Question(String text) {
		this.text = text;
		this.answers = new ArrayList<Answer>();
	}
	
	public String getText() {
		return this.text;
	}
	
	public Question setText(String text) {
		this.text = text;
		return this;
	}
	
	public List<Answer> getAnswers() {
		return this.answers;
	}
	
	public Question addAnswer(Answer answer) {
		answers.add(answer);
		return this;
	}
}

package com.coursera.android.capstone.smclient.controllers;

import org.magnum.videoup.client.oauth.SecuredRestBuilder;
import org.magnum.videoup.client.unsafe.EasyHttpClient;

import retrofit.RestAdapter.LogLevel;
import retrofit.client.ApacheClient;

public class ConnectionController {

	private final static ConnectionController mInstance = new ConnectionController();

	private static SymptomMgmtApi mLastSymptomMgmtApi;

	public static ConnectionController getInstance() {
		return mInstance;
	}

	public SymptomMgmtApi createClient(String username, String password,
			String clientId, String endpoint) {

		mLastSymptomMgmtApi = new SecuredRestBuilder()
				.setLoginEndpoint(endpoint + SymptomMgmtApi.TOKEN_PATH)
				.setUsername(username).setPassword(password)
				.setClientId(clientId)
				.setClient(new ApacheClient(new EasyHttpClient()))
				.setEndpoint(endpoint).setLogLevel(LogLevel.FULL).build()
				.create(SymptomMgmtApi.class);

		return mLastSymptomMgmtApi;
	}

	public SymptomMgmtApi getClient() {
		return mLastSymptomMgmtApi;
	}
}

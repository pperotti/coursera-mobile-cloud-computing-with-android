package com.coursera.android.capstone.smclient.sync;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/**
 * This service will be called by Android framework to start the SyncAdapter.
 */
public class SyncService extends Service {

    private static final String TAG = SyncService.class.getSimpleName();
    private static final Object SYNC_ADAPTER_LOCK = new Object();
    private SyncAdapter mSyncAdapter = null;

    /**
     * Thread-safe constructor, creates static {@link SyncAdapter} instance.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "SyncService: onCreate()");
        synchronized (SYNC_ADAPTER_LOCK) {
            if (mSyncAdapter == null) {
                mSyncAdapter = new SyncAdapter(getApplicationContext(), true);
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "SyncService: onBind()");
        return mSyncAdapter.getSyncAdapterBinder();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "SyncService: onDestroy()");
    }
}

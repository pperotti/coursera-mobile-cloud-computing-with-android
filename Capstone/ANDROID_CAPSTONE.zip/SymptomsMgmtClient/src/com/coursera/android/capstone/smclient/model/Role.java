package com.coursera.android.capstone.smclient.model;

/**
 * Retrieve the Role a particular login has. 
 */
public class Role {

	public static final String ROLE_DOCTOR = "doctor";
	public static final String ROLE_PATIENT = "patient";
	
	private String name;
	
	public Role() {
	}
	
	public Role setName(String name) {
		this.name = name;
		return this;
	}
	
	public String getName() {
		return this.name;
	}
	
}

package com.coursera.android.capstone.smclient.ui.activities;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.ui.fragment.LoginFragment;
import com.coursera.android.capstone.smclient.ui.fragment.LoginFragment.LoginActionListener;

/**
 * Concentrate the navigation for all the fragments related with adding an
 * account
 */
public class LoginActivity extends Activity implements LoginActionListener {

	private static final String TAG = LoginActivity.class.getSimpleName();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_login);

		openLoginFragment();
	}

	@Override
	public void onResume() {
		super.onResume();
	}

	public void onPause() {
		super.onPause();
	}

	private void openLoginFragment() {
		FragmentManager fragmentManager = getFragmentManager();
		fragmentManager.beginTransaction()
				.replace(R.id.content_frame, new LoginFragment()).commit();
	}

	@Override
	public void onLoginCompleted(Intent intent) {
		Log.i(TAG, "onLoginCompleted!");
		// Post the result on the caller activity
		setResult(Activity.RESULT_OK, intent);
		finish();
	}

	@Override
	public void onLoginError() {
		Log.i(TAG, "onLoginError!");
		Toast.makeText(getApplicationContext(),
				getString(R.string.error_login_failed), Toast.LENGTH_LONG)
				.show();
		openLoginFragment();
	}

}

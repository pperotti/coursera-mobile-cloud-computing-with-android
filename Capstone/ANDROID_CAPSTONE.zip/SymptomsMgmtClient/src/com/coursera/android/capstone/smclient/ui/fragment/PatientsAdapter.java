package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.model.CheckIn;
import com.coursera.android.capstone.smclient.model.Patient;
import com.coursera.android.capstone.smclient.model.Profile;

public class PatientsAdapter extends BaseAdapter implements Filterable
{
    private ArrayList<Patient> mItems = new ArrayList<Patient>();
    private ArrayList<Patient> mOriginalItems = new ArrayList<Patient>();
    
    private LayoutInflater mInflater;
    private ViewGroup mViewGroup = null;
    
    private String dateFormat, timeFormat;

    public PatientsAdapter(Context context)
    {
        mInflater = LayoutInflater.from(context);
        dateFormat = context.getString(R.string.patient_item_checkin);
        timeFormat = context.getString(R.string.patient_item_time);
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        Holder holder = null;
        if (convertView == null)
        {
            // Inflate
            convertView = mInflater.inflate(R.layout.patient_list_item, mViewGroup);

            holder = new Holder();
            holder.name = (TextView) convertView.findViewById(R.id.tvName);
            holder.date = (TextView) convertView.findViewById(R.id.tvDate);
            holder.time = (TextView) convertView
                    .findViewById(R.id.tvTime);

            // Create a holder and save it for later usage
            convertView.setTag(holder);
        } else
        {
            holder = (Holder) convertView.getTag();
        }

        // Get the item
        Patient currentItem = mItems.get(position);

        // Populate the items according to what was defined in the holder
        holder.name.setText(currentItem.getProfile().getName() + " " + currentItem.getProfile().getLastName());
        
        CheckIn lastCheckIn = currentItem.getLatestCheckIn();
        String date = "-";
        String time = "-";
        if ( lastCheckIn != null ) {
        	date = lastCheckIn.getDate();
        	time = lastCheckIn.getTime();
        } 
        
        holder.date.setText(String.format(dateFormat, date));
        holder.time.setText(String.format(timeFormat, time));

        return convertView;
    }

    @Override
    public int getCount()
    {
        return mItems.size();
    }

    @Override
    public Object getItem(int position)
    {
        return mItems.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        // Not needed for this scenario
        return 0;
    }

    public void setItems(ArrayList<Patient> items)
    {
    	mOriginalItems = items;
        mItems = items;
    }

	@Override
	public Filter getFilter() {
	
		Filter newFilter = new Filter() {
			@SuppressLint("DefaultLocale")
			@Override
			protected FilterResults performFiltering(CharSequence constraint) {
				
				FilterResults results = new FilterResults();
                ArrayList<Patient> FilteredArrayNames = new ArrayList<Patient>();

                constraint = constraint.toString().toLowerCase();
                int size = mItems.size();
                for (int i = 0; i < size; i++) {
                    
                    Profile profile = mItems.get(i).getProfile();
                    String patientFullName = profile.getName() + " " + profile.getLastName(); 
                    if ( patientFullName.toLowerCase().contains(constraint) ) {
                    	FilteredArrayNames.add(mItems.get(i));
                    }
                    
                }

                results.count = FilteredArrayNames.size();
                results.values = FilteredArrayNames;

                return results;
                
			}
			@SuppressWarnings("unchecked")
			@Override
			protected void publishResults(CharSequence constraint,
					FilterResults results) {
				
				mItems = (ArrayList<Patient>) results.values;
				
				notifyDataSetChanged();
			}
		};
		
		return newFilter;
	}

	public void restoreFilter() {
		mItems = mOriginalItems;
		notifyDataSetChanged();
	}
	
	// Holder for the UI items to be used in the list
    class Holder
    {
        TextView name;
        TextView date;
        TextView time;
    }
}



package com.coursera.android.capstone.smclient.sync;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.ContentResolver;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

public class SyncHelper {

    private static final String TAG = "SyncHelper";
    private static final String CONTENT_AUTHORITY = "com.coursera.android.capstone.smclient.datasync.provider";
    
    // An account type, in the form of a domain name
    public static final String ACCOUNT_TYPE = "smprofile";
    // The account name
    public static final String ACCOUNT = "syncaccount";

    private SyncHelper() {
    }

    /**
     * Create an entry for this application in the system account list, if it isn't already there.
     *
     * @param context Context
     */
    public static void createAccount(Context context) {
    	
    	Log.d(TAG, "createAccount()");
    	
        Account account = AuthenticatorService.getAccount();

        AccountManager accountManager =
                (AccountManager) context.getSystemService(Context.ACCOUNT_SERVICE);

        if (accountManager.addAccountExplicitly(account, null, null)) {
        	ContentResolver.setIsSyncable(account, CONTENT_AUTHORITY, 1);
        	ContentResolver.setSyncAutomatically(account, CONTENT_AUTHORITY, true);
        }

    }

    public static void forceRefresh() {
    	Log.d(TAG, "forceRefresh()");
        Bundle b = new Bundle();
        b.putBoolean(ContentResolver.SYNC_EXTRAS_MANUAL, true);
        b.putBoolean(ContentResolver.SYNC_EXTRAS_EXPEDITED, true);
        ContentResolver.requestSync(AuthenticatorService.getAccount(),
                CONTENT_AUTHORITY,
                b);
    }

    public static void runRefreshAttempt() {
    	Log.d(TAG, "runRefreshAttempt()");
    	ContentResolver.requestSync(
                AuthenticatorService.getAccount(),
                CONTENT_AUTHORITY,
                new Bundle());
    }
}

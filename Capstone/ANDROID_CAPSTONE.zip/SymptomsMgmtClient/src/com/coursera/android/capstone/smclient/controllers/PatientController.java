package com.coursera.android.capstone.smclient.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

import com.coursera.android.capstone.smclient.model.Patient;

/**
 * Handle all the operations related with Patients
 */
public class PatientController {

	public static final int SORT_CRITERIA_ALPHABETICALLY = 1;
	public static final int SORT_CRITERIA_BY_CHECKIN = 2;
	
	private static PatientController mInstance = new PatientController();
	
	private ArrayList<Patient> mList;
	private HashMap<String, Patient> mPatients = new HashMap<String, Patient>();
	
	private int mSortCriteria = SORT_CRITERIA_ALPHABETICALLY;
	
	public static PatientController getInstance() {
		return mInstance;
	}
	
	public PatientController setList(Collection<Patient> newList) {
		mList = new ArrayList<Patient>(newList);
		mPatients.clear();
		Iterator<Patient> patientIterator = mList.iterator();
		while ( patientIterator.hasNext() ) {
			Patient patient = patientIterator.next();
			mPatients.put(patient.getProfile().getRecordId(), patient);
		}
		return this;
	}
	
	public ArrayList<Patient> getList() {
		return mList;
	}

	public PatientController sortListByName() {
		Collections.sort(mList, new AZComparator());
		mSortCriteria = SORT_CRITERIA_ALPHABETICALLY;
		return this;
	}
	
	public int getSortCriteria() {
		return mSortCriteria;
	}

	public Patient getPatientById(String recordId) {
		return mPatients.get(recordId);
	}
	
	public void setPatientById(String recordId, Patient patient) {
		mPatients.put(recordId, patient);
	}
	
	//Add more method to ease the sorting to the consumers (evaluate set vs get approach)
	class AZComparator implements Comparator<Patient> {
		@Override
		public int compare(Patient lhs, Patient rhs) {
			return lhs.compareTo(rhs);
		}
	}
	
}

package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.CheckIn;
import com.coursera.android.capstone.smclient.model.Patient;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;
import com.coursera.android.capstone.smclient.services.SyncDoctor;

public class PatientCheckInHistoryFragment extends Fragment {

	private static final String TAG = PatientCheckInHistoryFragment.class.getSimpleName();

	private OperationReceiver mOperationReceiver = new OperationReceiver();

	// UI Elements
	private ListView lvCheckInHistory;
	private CheckInHistoryAdapter lvCheckInHistoryAdapter;

	public PatientCheckInHistoryFragment() {
	}
	
	@Override
	public void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_medicines, container,
				false);

		lvCheckInHistory = (ListView) rootView.findViewById(android.R.id.list);
		lvCheckInHistoryAdapter = new CheckInHistoryAdapter(getActivity());
		lvCheckInHistory.setAdapter(lvCheckInHistoryAdapter);
		lvCheckInHistory.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				//Get the check in entry and open the proper fragment
				openCheckInDetailsFragment(position);
			}
		});

		return rootView;
	}
	
	private void openCheckInDetailsFragment(int checkInPosition) {
		Bundle arguments = getArguments();
		arguments.putInt(BundleExtras.EXTRA_CHECKIN, checkInPosition);
		PatientCheckInDetailsFragment checkInDetailsFragment = new PatientCheckInDetailsFragment();
		checkInDetailsFragment.setArguments(arguments);
		getFragmentManager().beginTransaction().replace(R.id.content_frame, checkInDetailsFragment).commit();
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		refreshList();
		
		getActivity().getActionBar().setTitle(R.string.patientcheckinhistory_title);
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mOperationReceiver);
	}
	
	private void refreshList() {
		Bundle arguments = getArguments();
		String patientId = arguments.getString(BundleExtras.EXTRA_PATIENT_ID);
		Patient patient = PatientController.getInstance().getPatientById(patientId);
		
		ArrayList<CheckIn> list = (ArrayList<CheckIn>) patient.getCheckIns();
		lvCheckInHistoryAdapter.setItems(list);
		lvCheckInHistoryAdapter.notifyDataSetChanged();
	}
	
	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class OperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, TAG + " -> operation=" + operation);

			if (SyncDoctor.OPERATION.equals(operation)) {
				int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
						SMReceiver.RESULT_ERROR);
				if (SMReceiver.RESULT_OK == resultCode) {
					// OK - Update the adapter
					getActivity().runOnUiThread(new Runnable() {
						@Override
						public void run() {
							refreshList();
						}
					});
				} 
			}
		}
	}
}

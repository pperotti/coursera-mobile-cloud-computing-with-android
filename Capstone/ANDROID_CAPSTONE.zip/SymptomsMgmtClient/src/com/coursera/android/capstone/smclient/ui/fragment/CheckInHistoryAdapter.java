package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.model.CheckIn;

public class CheckInHistoryAdapter extends BaseAdapter implements Filterable {
	
	private ArrayList<CheckIn> mItems = new ArrayList<CheckIn>();
	private ArrayList<CheckIn> mOriginalItems = new ArrayList<CheckIn>();

	private LayoutInflater mInflater;
	private ViewGroup mViewGroup = null;

	public CheckInHistoryAdapter(Context context) {
		mInflater = LayoutInflater.from(context);
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		if (convertView == null) {
			// Inflate
			convertView = mInflater.inflate(R.layout.checkinhistory_list_item,
					mViewGroup);

			holder = new Holder();
			holder.date = (TextView) convertView.findViewById(R.id.tvDate);
			holder.time = (TextView) convertView.findViewById(R.id.tvTime);

			// Create a holder and save it for later usage
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}

		// Get the item
		CheckIn currentItem = mItems.get(position);

		// Populate the items according to what was defined in the holder
		holder.date.setText(currentItem.getDate());
		holder.time.setText(currentItem.getTime());

		return convertView;
	}

	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		// Not needed for this scenario
		return 0;
	}

	public void setItems(ArrayList<CheckIn> items) {
		mOriginalItems = items;
		mItems = items;
	}

	// Holder for the UI items to be used in the list
	class Holder {
		TextView date;
		TextView time;
	}

	@Override
	public Filter getFilter() {

		Filter newFilter = new Filter() {
			@SuppressLint("DefaultLocale")
			@Override
			protected FilterResults performFiltering(CharSequence constraint) {

				FilterResults results = new FilterResults();
				ArrayList<CheckIn> FilteredArrayNames = new ArrayList<CheckIn>();

				constraint = constraint.toString().toLowerCase();
				int size = mItems.size();
				for (int i = 0; i < size; i++) {
					String checkInDate = mItems.get(i).getDate();
					if (checkInDate.toLowerCase().contains(constraint)) {
						FilteredArrayNames.add(mItems.get(i));
					}
				}

				results.count = FilteredArrayNames.size();
				results.values = FilteredArrayNames;

				return results;

			}

			@SuppressWarnings("unchecked")
			@Override
			protected void publishResults(CharSequence constraint,
					FilterResults results) {
				mItems = (ArrayList<CheckIn>) results.values;
				notifyDataSetChanged();
			}
		};

		return newFilter;
	}

	public void restoreFilter() {
		mItems = mOriginalItems;
		notifyDataSetChanged();
	}

}

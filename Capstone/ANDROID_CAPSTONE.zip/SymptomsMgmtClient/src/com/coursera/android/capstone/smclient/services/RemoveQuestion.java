package com.coursera.android.capstone.smclient.services;

import java.util.Collection;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.QuestionController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Question;

public class RemoveQuestion implements Runnable {

	public static final String TAG = RemoveQuestion.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.REMOVE_QUESTION";

	public Intent mIntent;

	public RemoveQuestion(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			String questionText = mIntent.getStringExtra(BundleExtras.EXTRA_QUESTION_TEXT);
			if (questionText!=null) {
				Collection<Question> questions = client.deleteQuestion(questionText);
				QuestionController.getInstance().setList(questions);
				
				OperationExecutorIntentService.broadcastResultOK(OPERATION);
			} else {
				OperationExecutorIntentService.broadcastResultError(OPERATION);
			}
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

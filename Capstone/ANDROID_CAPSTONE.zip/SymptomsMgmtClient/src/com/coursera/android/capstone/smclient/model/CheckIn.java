package com.coursera.android.capstone.smclient.model;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * All the information related with one particular check-in.
 */
public class CheckIn implements Comparable<CheckIn> {

	private String timestamp;
	private List<Response> responses;

	public CheckIn() {
		responses = new ArrayList<Response>();
		timestamp = String.valueOf(System.currentTimeMillis());
	}

	public CheckIn setTimestamp(String timestamp) {
		this.timestamp = timestamp;
		return this;
	}

	public List<Response> getResponses() {
		return this.responses;
	}

	public void setResponses(List<Response> responses) {
		this.responses = responses;
	}

	public CheckIn addResponse(Response response) {
		responses.add(response);
		return this;
	}

	public String getTimestamp() {
		return this.timestamp;
	}

	public String getDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(Long.parseLong(timestamp));

		int rawDay = calendar.get(Calendar.DAY_OF_MONTH) + 1;
		String day = (rawDay < 10) ? "0" + rawDay : String.valueOf(rawDay);

		int rawMonth = calendar.get(Calendar.MONTH) + 1;
		String month = (rawMonth < 10) ? "0" + rawMonth : String
				.valueOf(rawMonth);

		return day + "-" + month + "-" + calendar.get(Calendar.YEAR);
	}

	public String getTime() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(Long.parseLong(timestamp));

		int rawHour = calendar.get(Calendar.HOUR_OF_DAY);
		String hour = (rawHour < 10) ? "0" + rawHour : String.valueOf(rawHour);

		int rawMinute = calendar.get(Calendar.MINUTE);
		String minute = (rawMinute < 10) ? "0" + rawMinute : String
				.valueOf(rawMinute);

		return hour + ":" + minute;
	}

	@Override
	public int compareTo(CheckIn another) {
		return timestamp.compareTo(another.getTimestamp());
	}
}

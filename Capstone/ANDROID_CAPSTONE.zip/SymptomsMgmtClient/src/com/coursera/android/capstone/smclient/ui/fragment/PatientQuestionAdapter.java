package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Question;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;
import com.coursera.android.capstone.smclient.services.RemovePatientQuestion;

public class PatientQuestionAdapter extends BaseAdapter implements Filterable {
	
	private ArrayList<Question> mItems = new ArrayList<Question>();
	private ArrayList<Question> mOriginalItems = new ArrayList<Question>();

	private LayoutInflater mInflater;
	private ViewGroup mViewGroup = null;
	private Bundle mArguments = null;

	public PatientQuestionAdapter(Context context, Bundle arguments) {
		mInflater = LayoutInflater.from(context);
		mArguments = arguments;
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		if (convertView == null) {
			// Inflate
			convertView = mInflater.inflate(R.layout.question_list_item,
					mViewGroup);

			holder = new Holder();
			holder.name = (TextView) convertView.findViewById(R.id.tvName);
			holder.remove = (ImageButton) convertView
					.findViewById(R.id.btRemove);

			// Create a holder and save it for later usage
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}

		// Get the item
		final Question currentItem = mItems.get(position);

		// Populate the items according to what was defined in the holder
		holder.name.setText(currentItem.getText());
		holder.remove.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = OperationExecutorIntentService.createOperationIntent(SMApplication.getInstance(), RemovePatientQuestion.OPERATION);
				intent.putExtras(mArguments);
				intent.putExtra(BundleExtras.EXTRA_QUESTION_TEXT, currentItem.getText());
				SMApplication.getInstance().startService(intent);
			}
		});

		return convertView;
	}

	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		// Not needed for this scenario
		return 0;
	}

	public void setItems(ArrayList<Question> items) {
		mOriginalItems = items;
		mItems = items;
	}

	// Holder for the UI items to be used in the list
	class Holder {
		TextView name;
		ImageButton remove;
	}
	
	@Override
	public Filter getFilter() {
		Filter newFilter = new Filter() {
			@SuppressLint("DefaultLocale")
			@Override
			protected FilterResults performFiltering(CharSequence constraint) {

				FilterResults results = new FilterResults();
				ArrayList<Question> FilteredArrayNames = new ArrayList<Question>();

				constraint = constraint.toString().toLowerCase();
				int size = mItems.size();
				for (int i = 0; i < size; i++) {

					String medName = mItems.get(i).getText();
					if (medName.toLowerCase().contains(constraint)) {
						FilteredArrayNames.add(mItems.get(i));
					}

				}

				results.count = FilteredArrayNames.size();
				results.values = FilteredArrayNames;

				return results;

			}

			@SuppressWarnings("unchecked")
			@Override
			protected void publishResults(CharSequence constraint,
					FilterResults results) {

				mItems = (ArrayList<Question>) results.values;

				notifyDataSetChanged();
			}
		};

		return newFilter;
	}

	public void restoreFilter() {
		mItems = mOriginalItems;
		notifyDataSetChanged();
	}

}

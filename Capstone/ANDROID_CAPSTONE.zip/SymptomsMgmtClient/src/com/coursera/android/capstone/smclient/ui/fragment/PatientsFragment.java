package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.model.Patient;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.GetPatientList;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;
import com.coursera.android.capstone.smclient.services.SyncDoctor;
import com.coursera.android.capstone.smclient.sync.SyncHelper;
import com.coursera.android.capstone.smclient.ui.activities.PatientDetailsActivity;

public class PatientsFragment extends Fragment {

	private static final String TAG = PatientsFragment.class.getSimpleName();

	private OperationReceiver mOperationReceiver = new OperationReceiver();

	// UI Elements
	private ListView lvPatientList;
	private PatientsAdapter lvPatientAdapter;
	private EditText etFilter;

	public PatientsFragment() {
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_patients, container,
				false);

		lvPatientList = (ListView) rootView.findViewById(android.R.id.list);
		lvPatientAdapter = new PatientsAdapter(getActivity());
		lvPatientList.setAdapter(lvPatientAdapter);
		lvPatientList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				onOptionsSelected(position);
			}
		});

		etFilter = (EditText) rootView.findViewById(R.id.etSearchFilter);
		etFilter.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// Log.i(TAG, "onTextChanged=" + s.toString() + " count=" +
				// count);
				// Left in blank on purpose
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// Left in blank on purpose
			}

			@Override
			public void afterTextChanged(Editable s) {

				String text = etFilter.getText().toString();
				Log.i(TAG,
						"afterTextChanged=" + text + " count=" + text.length());

				if (text.length() == 0) {
					lvPatientAdapter.restoreFilter();
				} else {
					lvPatientAdapter.getFilter().filter(text);
				}

			}
		});

		return rootView;
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);

		inflater.inflate(R.menu.patient_menu, menu);

		// Add new entry
		int criteria = PatientController.getInstance().getSortCriteria();
		if (PatientController.SORT_CRITERIA_ALPHABETICALLY == criteria) {
			menu.getItem(0).setVisible(false);
		} else if (PatientController.SORT_CRITERIA_BY_CHECKIN == criteria) {
			menu.getItem(1).setVisible(false);
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		boolean retValue = true;

		switch (item.getItemId()) {
		case R.id.menu_search:

			if (etFilter.getVisibility() == View.GONE) {
				etFilter.setVisibility(View.VISIBLE);
			} else {
				etFilter.setVisibility(View.GONE);
				etFilter.setText("");
			}

			break;
		case R.id.menu_sort_alphabetically:
			// TODO: Change sort criteria in the controller and reload adapter
			break;
		case R.id.menu_sort_by_checkin:
			// TODO: Change sort criteria in the controller and reload adapter
			break;
		case R.id.menu_sync:
			SyncHelper.forceRefresh();
			break;
		default:
			retValue = super.onOptionsItemSelected(item);
		}

		return retValue;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		OperationExecutorIntentService.runServiceOperation(GetPatientList.OPERATION);
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mOperationReceiver);
	}

	private void onOptionsSelected(int position) {

		// Open the patient's details
		Patient patient = (Patient) lvPatientAdapter.getItem(position);
		Intent intent = PatientDetailsActivity
				.createPatientDetailsActivityIntent(patient.getProfile()
						.getRecordId());
		getActivity().startActivity(intent);
	}

	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class OperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, TAG + " -> operation=" + operation);

			int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
					SMReceiver.RESULT_ERROR);
			if (GetPatientList.OPERATION.equals(operation)) {
				if (SMReceiver.RESULT_OK == resultCode) {
					// OK - Update the adapter
					refreshList();
				} else {
					// Error
					Toast.makeText(getActivity(),
							getString(R.string.error_on_get_patient_list),
							Toast.LENGTH_LONG).show();
				}
			} else if (SyncDoctor.OPERATION.equals(operation)) {
				if (SMReceiver.RESULT_OK == resultCode) {
					// OK - Update the adapter
					refreshList();
				}
			}
		}
	}

	private void refreshList() {
		ArrayList<Patient> patientList = PatientController
				.getInstance().getList();
		lvPatientAdapter.setItems(patientList);
		lvPatientAdapter.notifyDataSetChanged();
	}
}

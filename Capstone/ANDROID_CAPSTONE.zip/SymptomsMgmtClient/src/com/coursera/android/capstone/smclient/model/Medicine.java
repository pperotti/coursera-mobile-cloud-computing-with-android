package com.coursera.android.capstone.smclient.model;

/**
 * Represent a single medicine.
 */
public class Medicine implements Comparable<Medicine> {

	private String name;

	public Medicine() {
		//This is left in blank on purpose 
	}
	
	public Medicine(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public Medicine setName(String name) {
		this.name = name;
		return this;
	}

	@Override
	public int compareTo(Medicine another) {
		return name.compareTo(another.getName());
	}
	
}

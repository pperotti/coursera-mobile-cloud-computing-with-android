package com.coursera.android.capstone.smclient.ui.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.controllers.MedicineController;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.services.AddNewMedicine;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;

public class NewMedicineDialog extends DialogFragment {
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		// Use the Builder class for convenient dialog construction
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

		LayoutInflater inflater = getActivity().getLayoutInflater();
		ViewGroup parentView = null;
		View dialogView = inflater.inflate(R.layout.new_medicine_dialog,
				parentView);
		final EditText etNewMedicine = (EditText) dialogView
				.findViewById(R.id.etNewMedicine);
		builder.setView(dialogView)
				.setMessage(R.string.new_medicine_dialog_title)
				.setPositiveButton(R.string.new_medicine_dialog_add,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {

								// Validates whether the medicine already exists
								// or not
								String medicineName = etNewMedicine.getText()
										.toString();
								if (TextUtils.isEmpty(medicineName)) {
									Toast.makeText(
											SMApplication.getInstance(),
											getString(R.string.error_empty_medicine),
											Toast.LENGTH_LONG).show();
									return;
								} else if (MedicineController.getInstance().contains(medicineName)) {
									Toast.makeText(
											SMApplication.getInstance(),
											getString(R.string.error_medicine_already_exists),
											Toast.LENGTH_LONG).show();
									return;
								}

								// Add new med to the server
								Intent intent = OperationExecutorIntentService.createOperationIntent(SMApplication.getInstance(), AddNewMedicine.OPERATION);
								intent.putExtra(BundleExtras.EXTRA_MEDICINE_NAME, medicineName);
								SMApplication.getInstance().startService(intent);

								// Close the dialog
								getDialog().dismiss();
							}
						})
				.setNegativeButton(R.string.new_medicine_dialog_cancel,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								// Dismiss Creation
								getDialog().cancel();
							}
						});
		// Create the AlertDialog object and return it
		return builder.create();
	}
}
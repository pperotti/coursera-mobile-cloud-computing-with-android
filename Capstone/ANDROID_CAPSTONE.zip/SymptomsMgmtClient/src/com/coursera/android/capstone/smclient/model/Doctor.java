package com.coursera.android.capstone.smclient.model;

import java.util.Collection;
import java.util.HashMap;

/**
 * Doctor's information
 */
public class Doctor {

	Profile profile;

	// Patient's list
	HashMap<String, Patient> mPatients = new HashMap<String, Patient>();

	public Doctor() {
	}
	
	public Doctor(Profile profile) {
		this.profile = profile;
	}

	public Profile getProfile() {
		return this.profile;
	}

	public Doctor setProfile(Profile profile) {
		this.profile = profile;
		return this;
	}

	public Collection<Patient> getPatients() {
		return mPatients.values();
	}

	public Doctor addPatient(Patient patient) {
		if (patient != null && patient.getProfile() != null
				&& patient.getProfile().getRecordId() != null) {
			mPatients.put(patient.getProfile().getRecordId(), patient);
		}
		return this;
	}

}

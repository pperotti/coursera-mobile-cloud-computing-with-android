package com.coursera.android.capstone.smclient.services;

import java.util.Collection;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.CheckInController;
import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.CheckIn;

public class GetCheckInList implements Runnable {

	public static final String TAG = GetCheckInList.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.GET_CHECKIN_LIST";

	public Intent mIntent;

	public GetCheckInList(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			String id = ProfileController.getInstance().getCurrentId();
			Collection<CheckIn> checkInList = client.getPatientCheckIns(id);

			CheckInController.getInstance().setList(checkInList).sortListByTime();
			OperationExecutorIntentService.broadcastResultOK(OPERATION);
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

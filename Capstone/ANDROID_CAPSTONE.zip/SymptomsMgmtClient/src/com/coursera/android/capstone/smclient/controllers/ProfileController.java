package com.coursera.android.capstone.smclient.controllers;

import com.coursera.android.capstone.smclient.model.Profile;

public class ProfileController {

	private static ProfileController mInstance = new ProfileController();
	
	private Profile mCurrentProfile;
	private Profile mProfileToUpdate;
	private String mId;
	
	public static ProfileController getInstance() {
		return mInstance;
	}
	
	public ProfileController setCurrentProfile(String id, Profile profile) {
		this.mCurrentProfile = profile;
		this.mId = id;
		return mInstance;
	}

	public Profile getCurrentProfile() {
		return mCurrentProfile;
	}
	
	public String getCurrentId() {
		return mId;
	}
	
	public ProfileController setProfileToUpdate(Profile profile) {
		mProfileToUpdate = profile;
		return this;
	}
	
	public Profile getProfileToUpdate() {
		return mProfileToUpdate;
	}
	
	public Profile getNewProfileToUpdate() {
		Profile newProfile = new Profile();
		newProfile.setBirthDay(mCurrentProfile.getBirthDay());
		newProfile.setEmail(mCurrentProfile.getEmail());
		newProfile.setLastName(mCurrentProfile.getLastName());
		newProfile.setName(mCurrentProfile.getName());
		newProfile.setRecordId(getCurrentId());
		newProfile.setRole(mCurrentProfile.getRole());
		return newProfile;
	}
	
}

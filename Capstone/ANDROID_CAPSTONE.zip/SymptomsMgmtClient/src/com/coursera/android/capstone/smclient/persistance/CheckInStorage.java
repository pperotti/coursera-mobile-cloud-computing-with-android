package com.coursera.android.capstone.smclient.persistance;

import java.util.Set;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.model.CheckIn;
import com.google.gson.Gson;

/**
 * Persist the CheckIn object into a json format. This object is used to
 * persists for a short period of time those checkins that were not sent to the
 * cloud.
 */
public class CheckInStorage {

	private static CheckInStorage mInstance = new CheckInStorage();
	private static final String TAG = CheckInStorage.class.getSimpleName();
	
	private SharedPreferences mStorage;
	private Gson mGson = new Gson();

	private CheckInStorage() {
		mStorage = SMApplication.getInstance().getSharedPreferences("SMSPS",
				Context.MODE_PRIVATE);
	}

	public static CheckInStorage getInstance() {
		return mInstance;
	}

	/**
	 * Persists locally a CheckIn object
	 * 
	 * @param checkIn
	 */
	public void addCheckIn(CheckIn checkIn) {
		String checkInData = mGson.toJson(checkIn);
		String checkInKey = checkIn.getTimestamp();
		
		Log.i(TAG, "CheckInData=>" + checkInData);
		
		mStorage.edit().putString(checkInKey, checkInData).commit();
	}

	/**
	 * Retrieve the CheckIn object from the key used inside the storage
	 * 
	 * @param checkInKey
	 * @return
	 */
	public CheckIn getCheckIn(String checkInKey) {
		CheckIn checkIn = null;
		if (mStorage.contains(checkInKey)) {
			String checkInData = mStorage.getString(checkInKey, null);
			if (checkInData != null) {
				checkIn = mGson.fromJson(checkInData, CheckIn.class);
			}
		}
		return checkIn;
	}

	/**
	 * Remove a checkin from its key
	 * 
	 * @param key
	 */
	public void removeCheckIn(String key) {
		if (key != null) {
			mStorage.edit().remove(key).commit();
		}
	}

	/**
	 * @return Retrieve all the checkIns keys not yet sent to the server
	 */
	public Set<String> getCheckInKeys() {
		return mStorage.getAll().keySet();
	}
}

package com.coursera.android.capstone.smclient.services;

import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

public class OperationExecutorIntentService extends IntentService {

	private static final String TAG = OperationExecutorIntentService.class
			.getSimpleName();

	public static final String ACTION_RUN_OPERATION = "com.coursera.android.smclient.actions.ACTION_RUN_OPERATION";
	public static final String EXTRA_OPERATION = "com.coursera.android.smclient.extras.OPERATION";

	public OperationExecutorIntentService() {
		super("OperationExecutorIntentService");
	}

	public OperationExecutorIntentService(String name) {
		super(name);
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		Log.i(TAG,
				"OperationExecutorIntentService onHandleIntent=>"
						+ intent.getAction());
		Runnable newTask = OperationRunnerFactory.createOperationRunner(
				getApplicationContext(), intent);
		if (newTask != null) {
			newTask.run();
		}
	}

	// Factory Method for the intent that will enable how to start each intent service
	public static Intent createOperationIntent(Context context, String operation) {
		Intent newIntent = new Intent();
		if (context != null) {
			newIntent = new Intent(context,
					OperationExecutorIntentService.class);
		}
		newIntent
				.setAction(OperationExecutorIntentService.ACTION_RUN_OPERATION);
		newIntent.putExtra(OperationExecutorIntentService.EXTRA_OPERATION,
				operation);
		return newIntent;
	}
	
	// Trigger service operation with the service specified
	public static void runServiceOperation(String serviceOperation) {
		Intent intent = createOperationIntent(SMApplication.getInstance(), serviceOperation);
		SMApplication.getInstance().startService(intent);
	}

	// Broadcast RESULT_OK for the operation specified
	public static void broadcastResultOK(String operation) {
		Intent intent = SMReceiver.createResultOperationIntent(operation);
		intent.putExtra(SMReceiver.EXTRA_RESULT, SMReceiver.RESULT_OK);
		LocalBroadcastManager.getInstance(SMApplication.getInstance())
				.sendBroadcast(intent);
	}

	// Broadcast RESULT_ERROR for the operation specified
	public static void broadcastResultError(String operation) {
		Intent intent = SMReceiver.createResultOperationIntent(operation);
		intent.putExtra(SMReceiver.EXTRA_RESULT, SMReceiver.RESULT_ERROR);
		LocalBroadcastManager.getInstance(SMApplication.getInstance())
				.sendBroadcast(intent);
	}
}

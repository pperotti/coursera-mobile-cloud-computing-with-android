package com.coursera.android.capstone.smclient.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import com.coursera.android.capstone.smclient.model.Medicine;

/**
 * Handle all the operations related with Medicine
 */
public class MedicineController {

	private static MedicineController mInstance = new MedicineController();

	private ArrayList<Medicine> mList;

	public static MedicineController getInstance() {
		return mInstance;
	}

	public MedicineController setList(Collection<Medicine> newList) {
		mList = new ArrayList<Medicine>(newList);
		return this;
	}

	public ArrayList<Medicine> getList() {
		return mList;
	}

	public MedicineController sortListByName() {
		Collections.sort(mList, new AZComparator());
		return this;
	}

	public boolean contains(String medicineName) {
		Iterator<Medicine> medIterator = mList.iterator();
		while (medIterator.hasNext()) {
			if (medIterator.next().getName().equals(medicineName)) {
				return true;
			}
		}
		return false;
	}

	// Add more method to ease the sorting to the consumers (evaluate set vs get
	// approach)
	class AZComparator implements Comparator<Medicine> {

		@Override
		public int compare(Medicine lhs, Medicine rhs) {
			return lhs.compareTo(rhs);
		}
	}

}

package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.stats.StatsResult;

public class CheckInGraphDetailsAdapter extends BaseAdapter {
	
	private ArrayList<StatsResult.StatsEntry> mItems = new ArrayList<StatsResult.StatsEntry>();

	private LayoutInflater mInflater;
	private ViewGroup mViewGroup = null;
	private int mTotalResults = 0;

	public CheckInGraphDetailsAdapter(Context context) {
		mInflater = LayoutInflater.from(context);
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		if (convertView == null) {
			// Inflate
			convertView = mInflater.inflate(R.layout.checkin_graphical_details_list_item,
					mViewGroup);

			holder = new Holder();
			holder.reference = (TextView) convertView.findViewById(R.id.tvResponseText);
			holder.progress = (ProgressBar) convertView.findViewById(R.id.pbResponseProgress);
			holder.number = (TextView) convertView.findViewById(R.id.tvNumericProgress);

			// Create a holder and save it for later usage
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}

		// Get the item
		StatsResult.StatsEntry currentItem = mItems.get(position);

		// Populate the items according to what was defined in the holder
		holder.reference.setText(currentItem.getText());
		holder.progress.setMax(mTotalResults);
		holder.progress.setProgress(currentItem.getCount());
		holder.number.setText(String.valueOf(currentItem.getCount()));

		return convertView;
	}

	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	public void setItems(ArrayList<StatsResult.StatsEntry> items) {
		mItems = items;
	}

	public void setTotalResults(int totalResults) {
		mTotalResults = totalResults;
	}
	
	// Holder for the UI items to be used in the list
	class Holder {
		TextView reference;
		ProgressBar progress;
		TextView number;
	}
}

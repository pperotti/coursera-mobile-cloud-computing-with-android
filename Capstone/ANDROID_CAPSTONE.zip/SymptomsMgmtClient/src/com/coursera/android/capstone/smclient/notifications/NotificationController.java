package com.coursera.android.capstone.smclient.notifications;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.support.v4.app.NotificationCompat;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;

public final class NotificationController {

	private static NotificationController mNotificationController = new NotificationController();

	private NotificationController() {
	}

	public static NotificationController getInstance() {
		return mNotificationController;
	}

	/**
	 * Launch a traditional notification. At this point this is only used for to
	 * alert the patient that it is time to check-in and to a doctor to notify
	 * that there is a patient that requires his attention.
	 * 
	 * @param id
	 *            The id to use to launch notification. If -1 is passed, a
	 *            random value will be used
	 * @param title
	 *            The string to display as title of the notification
	 * @param content
	 *            The string to display as content of the notification
	 * @param iconRes
	 *            The icon for the notification
	 * @param contentPI
	 *            The Pending Intent that is will be executed when there is an
	 *            action to take
	 */
	public void launchNotification(int id, String title, String content,
			int iconRes, PendingIntent contentPI) {
		NotificationCompat.Builder builder = new NotificationCompat.Builder(
				SMApplication.getInstance())
				.setSmallIcon(R.drawable.ic_launcher).setContentTitle(title)
				.setContentText(content);
		if (contentPI != null) {
			builder.setContentIntent(contentPI);
		}
		builder.setAutoCancel(true);
		NotificationManager nm = (NotificationManager) SMApplication
				.getInstance().getSystemService(Context.NOTIFICATION_SERVICE);
		nm.notify(id, builder.build());
	}

}

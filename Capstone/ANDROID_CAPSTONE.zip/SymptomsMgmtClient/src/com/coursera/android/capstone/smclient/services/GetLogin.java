package com.coursera.android.capstone.smclient.services;

import java.util.Collection;
import java.util.List;

import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.MedicineController;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.controllers.QuestionController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.Medicine;
import com.coursera.android.capstone.smclient.model.Profile;
import com.coursera.android.capstone.smclient.model.Question;
import com.coursera.android.capstone.smclient.model.Role;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;

/**
 * Identify whether the information entered by the user succeed and if so,
 * represents a PATIENT or a DOCTOR.
 * 
 * The event "LOGIN" will be broadcasted with an OK or ERROR result code.
 */
public class GetLogin implements Runnable {

	public static final String TAG = GetLogin.class.getSimpleName();

	/**
	 * Action to indicate its receivers on how the LOGIN command was executed
	 */
	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.GET_LOGIN";
	public static final String USERNAME = "com.coursera.android.capstone.smclient.extras.USER";
	public static final String PASSWORD = "com.coursera.android.capstone.smclient.extras.PASS";
	public static final String CLIENT_ID = "com.coursera.android.capstone.smclient.extras.CLIENTID";
	public static final String ENDPOINT = "com.coursera.android.capstone.smclient.extras.ENDPOINT";
	public static final String EXTRA_ROLE = "com.coursera.android.capstone.smclient.extras.EXTRA_ROLE";

	public Intent mIntent;

	public GetLogin(Intent intent) {
		mIntent = intent;
	}

	public void run() {

		// Get information from the UI
		String username = mIntent.getStringExtra(USERNAME);
		String password = mIntent.getStringExtra(PASSWORD);
		String clientId = mIntent.getStringExtra(CLIENT_ID);
		String endpoint = mIntent.getStringExtra(ENDPOINT);

		Log.d(TAG, "onHandleIntent -> " + mIntent.getAction() + "\n" 
				+ " username=" + username
				+ " password=" + password
				+ " clientId=" + clientId
				+ " endpoint=" + endpoint
		);

		// Parse response
		try {
			// Do request
			SymptomMgmtApi serviceClient = ConnectionController.getInstance().createClient(
					username, password, clientId, endpoint);
			
			Role role = serviceClient.getRole(username);
			Profile profile = null;
			
			if (Role.ROLE_DOCTOR.equals(role.getName())) {
				profile = serviceClient.getDoctorProfile(username);
				
				//Get the medicines related with that profile
				Collection<Medicine> medicines = serviceClient.getMedicines();
				MedicineController.getInstance().setList(medicines);
				
				//Get the custom questions related with that 
				List<Question> questions = serviceClient.getQuestions();
				QuestionController.getInstance().setList(questions);

			} else if (Role.ROLE_PATIENT.equals(role.getName())) {
				profile = serviceClient.getPatientProfile(username);
				
				//Get the medicines related with that profile
				List<Medicine> medicines = serviceClient.getPatientMedicines(profile.getRecordId());
				MedicineController.getInstance().setList(medicines);
				
				//Get the custom questions related with that 
				List<Question> questions = serviceClient.getPatientQuestions(profile.getRecordId());
				QuestionController.getInstance().setList(questions);
			}
			
			if ( profile != null ) {
				ProfileController.getInstance().setCurrentProfile(username, profile);
				onOK(role.getName());
			}

		} catch (Exception re) {
			Log.e(TAG, re.getMessage());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}

	public void onOK(String role) {
		Intent intent = SMReceiver.createResultOperationIntent(OPERATION);
		intent.putExtra(SMReceiver.EXTRA_RESULT, SMReceiver.RESULT_OK);
		intent.putExtra(EXTRA_ROLE, role);
		LocalBroadcastManager.getInstance(SMApplication.getInstance())
				.sendBroadcast(intent);
	}
}

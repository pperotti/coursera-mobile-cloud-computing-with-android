package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.model.Medicine;

public class NewPatientMedicineAdapter extends BaseAdapter implements Filterable {
	
	private ArrayList<Medicine> mItems = new ArrayList<Medicine>();
	private ArrayList<Medicine> mOriginalItems = new ArrayList<Medicine>();

	private LayoutInflater mInflater;
	private ViewGroup mViewGroup = null;

	public NewPatientMedicineAdapter(Context context) {
		mInflater = LayoutInflater.from(context);
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		if (convertView == null) {
			// Inflate
			convertView = mInflater.inflate(R.layout.new_patient_medicine_list_item,
					mViewGroup);

			holder = new Holder();
			holder.name = (TextView) convertView.findViewById(R.id.tvName);

			// Create a holder and save it for later usage
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}

		// Get the item
		final Medicine currentItem = mItems.get(position);

		// Populate the items according to what was defined in the holder
		holder.name.setText(currentItem.getName());

		return convertView;
	}

	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		// Not needed for this scenario
		return 0;
	}

	public void setItems(ArrayList<Medicine> items) {
		mOriginalItems = items;
		mItems = items;
	}

	// Holder for the UI items to be used in the list
	class Holder {
		TextView name;
	}

	@Override
	public Filter getFilter() {

		Filter newFilter = new Filter() {
			@SuppressLint("DefaultLocale")
			@Override
			protected FilterResults performFiltering(CharSequence constraint) {

				FilterResults results = new FilterResults();
				ArrayList<Medicine> FilteredArrayNames = new ArrayList<Medicine>();

				constraint = constraint.toString().toLowerCase();
				int size = mItems.size();
				for (int i = 0; i < size; i++) {

					String medName = mItems.get(i).getName();
					if (medName.toLowerCase().contains(constraint)) {
						FilteredArrayNames.add(mItems.get(i));
					}

				}

				results.count = FilteredArrayNames.size();
				results.values = FilteredArrayNames;

				return results;

			}

			@SuppressWarnings("unchecked")
			@Override
			protected void publishResults(CharSequence constraint,
					FilterResults results) {

				mItems = (ArrayList<Medicine>) results.values;

				notifyDataSetChanged();
			}
		};

		return newFilter;
	}

	public void restoreFilter() {
		mItems = mOriginalItems;
		notifyDataSetChanged();
	}

}

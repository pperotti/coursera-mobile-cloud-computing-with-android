package com.coursera.android.capstone.smclient.services;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Patient;

public class RemovePatientQuestion implements Runnable {

	public static final String TAG = RemovePatientQuestion.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.REMOVE_PATIENT_QUESTION";

	public Intent mIntent;

	public RemovePatientQuestion(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			String questionText = mIntent.getStringExtra(BundleExtras.EXTRA_QUESTION_TEXT);
			String patientId = mIntent.getStringExtra(BundleExtras.EXTRA_PATIENT_ID);
			if (questionText!=null && patientId != null) {
				Patient updatedPatient = client.deletePatientQuestion(patientId, questionText);
				PatientController.getInstance().setPatientById(patientId, updatedPatient);
				
				OperationExecutorIntentService.broadcastResultOK(OPERATION);
			} else {
				OperationExecutorIntentService.broadcastResultError(OPERATION);
			}
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

package com.coursera.android.capstone.smclient.services;

import java.util.Collection;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.MedicineController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Medicine;

public class RemoveMedicine implements Runnable {

	public static final String TAG = RemoveMedicine.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.REMOVE_MEDICINE";

	public Intent mIntent;

	public RemoveMedicine(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			String medicineName = mIntent.getStringExtra(BundleExtras.EXTRA_MEDICINE_NAME);
			if (medicineName!=null) {
				Collection<Medicine> medicines = client.deleteMedicine(medicineName);
				MedicineController.getInstance().setList(medicines);
				OperationExecutorIntentService.broadcastResultOK(OPERATION);
			} else {
				Log.e(TAG, "Medicine NOT Removed!");
				OperationExecutorIntentService.broadcastResultError(OPERATION);
			}
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

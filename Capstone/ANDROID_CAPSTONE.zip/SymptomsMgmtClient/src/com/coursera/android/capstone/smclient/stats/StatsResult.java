package com.coursera.android.capstone.smclient.stats;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class StatsResult {
	private int mTotalResponses = 0;
	private HashMap<String, StatsEntry> mExistingResponses = new HashMap<String, StatsEntry>();
	private ArrayList<StatsEntry> mStatsEntries = new ArrayList<StatsResult.StatsEntry>();
	
	public void add(String text) {
		StatsEntry statsEntry = null;
		if (mExistingResponses.containsKey(text)) {
			statsEntry = mExistingResponses.get(text);
			statsEntry.add();
		} else {
			statsEntry = new StatsEntry(text);
		}
		mExistingResponses.put(text, statsEntry);
		mTotalResponses++;
	}
	
	public int getTotalResponses() {
		return mTotalResponses;
	}
	

	public void complete() {
		mStatsEntries = new ArrayList<StatsResult.StatsEntry>(mExistingResponses.values());
	}
	
	public List<StatsEntry> getExistingStatsEntries() {
		return mStatsEntries;
	}
	
	public class StatsEntry {
		private String mText;
		private int mCount;

		public StatsEntry(String text) {
			mText = text;
			mCount = 1;
		}
		
		public int getCount() {
			return mCount;
		}

		public void add() {
			mCount++;
		}

		public String getText() {
			return mText;
		}

		public void setText(String text) {
			mText = text;
		}

	}
}

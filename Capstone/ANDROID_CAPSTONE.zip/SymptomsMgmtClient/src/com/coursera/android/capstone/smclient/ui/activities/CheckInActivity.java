package com.coursera.android.capstone.smclient.ui.activities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.CheckInController;
import com.coursera.android.capstone.smclient.controllers.MedicineController;
import com.coursera.android.capstone.smclient.controllers.QuestionController;
import com.coursera.android.capstone.smclient.model.Answer;
import com.coursera.android.capstone.smclient.model.EnhancedCheckIn;
import com.coursera.android.capstone.smclient.model.Medicine;
import com.coursera.android.capstone.smclient.model.Question;
import com.coursera.android.capstone.smclient.model.Response;

public class CheckInActivity extends Activity {

	// Panel Intro
	LinearLayout llIntro;
	TextView tvIntroMessage;
	Button btIntroButton;

	// General Panel for questions
	LinearLayout llMO;
	TextView tvMOTitle;
	ListView lvMOOptions;
	ArrayAdapter<String> mArrayAdapter;

	// Panel C - Date
	RelativeLayout rlDate;
	DatePicker dpDate;
	Button btDateNext;

	// Panel D - Time
	RelativeLayout rlTime;
	TimePicker tpTime;
	Button btTimeNext;

	// States related with the checkin process
	enum CheckInState {

		/**
		 * The app shows the initial screen
		 */
		INTRO,

		/*
		 * The screen where "did you take your medicine?" question is presented
		 */
		STEP1,

		/*
		 * The screen where the date when the medicine was taken is asked for.
		 */
		DATE,

		/*
		 * The screen where the time of the check in is asked
		 */
		TIME,

		/*
		 * The screen where "did you take medicine 'x'?" with YES/NO answer is
		 * presented
		 */
		MEDICINES,

		/*
		 * The screen where each custom questoin is asked with custom answers
		 */
		CUSTOM_QUESTIONS;
	}

	// Current State
	CheckInState mCurrentCheckInState = CheckInState.INTRO;
	EnhancedCheckIn mTempCheckIn;

	// Options
	List<String> mOptions;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_checkin);

		// Panel 1
		llIntro = (LinearLayout) findViewById(R.id.llIntro);
		tvIntroMessage = (TextView) findViewById(R.id.tvIntroTitle);
		btIntroButton = (Button) findViewById(R.id.btIntroButton);
		btIntroButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				onClickCheckIn();
			}
		});

		// Panel 2
		llMO = (LinearLayout) findViewById(R.id.llMO);
		tvMOTitle = (TextView) findViewById(R.id.tvMOTitle);
		lvMOOptions = (ListView) findViewById(R.id.lvMOOptions);
		mArrayAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, android.R.id.text1);
		lvMOOptions.setAdapter(mArrayAdapter);
		lvMOOptions.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				onOptionsSelected(position);
			}
		});

		// Panel 3
		rlDate = (RelativeLayout) findViewById(R.id.rlDate);
		dpDate = (DatePicker) findViewById(R.id.dpDate);
		btDateNext = (Button) findViewById(R.id.btDateNext);
		btDateNext.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				onClickDate();
			}
		});

		// Panel 4
		rlTime = (RelativeLayout) findViewById(R.id.rlWhen);
		tpTime = (TimePicker) findViewById(R.id.tpTime);
		btTimeNext = (Button) findViewById(R.id.btTimeNext);
		btTimeNext.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				onClickTime();
			}
		});
		
		// A new temp checkin object will be created each time the ACTIVITY is
		// created, all unsaved data so far will be lost
		if (savedInstanceState == null) {
			mTempCheckIn = new EnhancedCheckIn();
			CheckInController.getInstance().setTempCheckIn(mTempCheckIn);
		} else {
			String step = savedInstanceState.getString("step");
			mCurrentCheckInState = CheckInState.valueOf(step);
			mTempCheckIn = CheckInController.getInstance().getTempCheckIn();

			if (CheckInState.STEP1 == mCurrentCheckInState) {
				onClickCheckIn();
			} else if (CheckInState.DATE == mCurrentCheckInState) {
				showDatePanel();
			}
			if (CheckInState.TIME == mCurrentCheckInState) {
				showTimePanel();
			}
			if (CheckInState.MEDICINES == mCurrentCheckInState) {
				int position = CheckInController.getInstance()
						.getLastTempMedicineIndex();
				chooseTheRightMedicine(position);
			}
			if (CheckInState.CUSTOM_QUESTIONS == mCurrentCheckInState) {
				int position = CheckInController.getInstance()
						.getLastTempQuestionIndex();
				chooseTheRightQuestion(position);
			}
		}
	}

	private void onClickCheckIn() {
		mCurrentCheckInState = CheckInState.STEP1;
		mOptions = Arrays.asList(getResources().getStringArray(
				R.array.checkin_question_did_you_take_medicine_options));
		showMOPanel(getString(R.string.checkin_question_did_you_take_medicine),
				mOptions);
	}

	private void onClickDate() {
		
		mTempCheckIn.setDate(dpDate.getDayOfMonth(), dpDate.getMonth(), dpDate.getYear());
		
		showTimePanel();
	}

	private void onClickTime() {
		
		mTempCheckIn.setTime(tpTime.getCurrentHour(), tpTime.getCurrentMinute());
		
		chooseTheRightMedicine(0);
	}

	private void chooseTheRightMedicine(int position) {
		mCurrentCheckInState = CheckInState.MEDICINES;

		if (mOptions == null) {
			mOptions = Arrays.asList(getResources().getStringArray(
					R.array.checkin_question_did_you_take_medicine_options));
		}

		ArrayList<Medicine> medicines = MedicineController.getInstance()
				.getList();
		if (medicines.size() > 0 && position < medicines.size()) {
			CheckInController.getInstance().setLastTempMedicineIndex(position);
			String questionFormat = getString(R.string.checkin_question_did_you_take_medicine_x);
			Medicine medicine = medicines.get(position);
			showMOPanel(String.format(questionFormat, medicine.getName()),
					mOptions);
		} else {
			// Show the question panel
			chooseTheRightQuestion(0);
		}
	}

	private void chooseTheRightQuestion(int position) {
		mCurrentCheckInState = CheckInState.CUSTOM_QUESTIONS;

		ArrayList<Question> questions = QuestionController.getInstance()
				.getList();
		if (questions.size() > 0 && position < questions.size()) {
			CheckInController.getInstance().setLastTempQuestionIndex(position);
			Question question = questions.get(position);
			mOptions = new ArrayList<String>();
			List<Answer> answers = question.getAnswers();
			Iterator<Answer> iterator = answers.iterator();
			while (iterator.hasNext()) {
				Answer answer = iterator.next();
				mOptions.add(answer.getAnswerText());
			}
			showMOPanel(question.getText(), mOptions);
		} else {
			// Show the question panel
			CheckInController.getInstance().completeProcess();
			finish();
		}
	}

	private void onOptionsSelected(int position) {

		if (CheckInState.STEP1 == mCurrentCheckInState) {
			// Index 0 - YES
			if (position == 0) {
				// Continue with date and time
				showDatePanel();
			} else {
				CheckInController.getInstance().completeProcess();
				finish();
			}
		} else if (CheckInState.MEDICINES == mCurrentCheckInState) {
			mTempCheckIn.addResponse(new Response(tvMOTitle.getText().toString(),
					mArrayAdapter.getItem(position)));

			int index = CheckInController.getInstance()
					.getLastTempMedicineIndex();
			chooseTheRightMedicine(++index);

		} else if (CheckInState.CUSTOM_QUESTIONS == mCurrentCheckInState) {
			mTempCheckIn.addResponse(new Response(tvMOTitle.getText().toString(),
					mArrayAdapter.getItem(position)));

			int index = CheckInController.getInstance()
					.getLastTempQuestionIndex();
			chooseTheRightQuestion(++index);
		}

	}

	private void showMOPanel(String text, List<String> options) {
		llIntro.setVisibility(View.GONE);
		llMO.setVisibility(View.VISIBLE);
		rlDate.setVisibility(View.GONE);
		rlTime.setVisibility(View.GONE);

		// Set the title
		tvMOTitle.setText(text);

		mArrayAdapter.clear();
		mArrayAdapter.addAll(options);
		mArrayAdapter.notifyDataSetChanged();
	}

	private void showDatePanel() {
		llIntro.setVisibility(View.GONE);
		llMO.setVisibility(View.GONE);
		rlDate.setVisibility(View.VISIBLE);
		rlTime.setVisibility(View.GONE);

		mCurrentCheckInState = CheckInState.DATE;
	}

	private void showTimePanel() {
		llIntro.setVisibility(View.GONE);
		llMO.setVisibility(View.GONE);
		rlDate.setVisibility(View.GONE);
		rlTime.setVisibility(View.VISIBLE);

		mCurrentCheckInState = CheckInState.TIME;
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putString("step", mCurrentCheckInState.name());
		super.onSaveInstanceState(outState);
	}
}

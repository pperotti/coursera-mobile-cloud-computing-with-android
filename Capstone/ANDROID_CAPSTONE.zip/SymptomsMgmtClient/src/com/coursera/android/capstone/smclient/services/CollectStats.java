package com.coursera.android.capstone.smclient.services;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.stats.StatsCollector;

public class CollectStats implements Runnable {

	public static final String TAG = CollectStats.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.COLLECT_STATS";

	public Intent mIntent;

	public CollectStats(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			String patientId = mIntent.getStringExtra(BundleExtras.EXTRA_PATIENT_ID);
			String questionText = mIntent.getStringExtra(BundleExtras.EXTRA_QUESTION_TEXT);
			
			if (questionText!=null && patientId != null ) {

				StatsCollector.getInstance().collectStatsForPatientId(patientId, questionText);
				
				OperationExecutorIntentService.broadcastResultOK(OPERATION);
			} else {
				OperationExecutorIntentService.broadcastResultError(OPERATION);
			}
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

package com.coursera.android.capstone.smclient.receiver;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.notifications.NotificationController;
import com.coursera.android.capstone.smclient.ui.activities.CheckInActivity;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		
		Log.i(AlarmReceiver.class.getSimpleName(), "onReceive!");
		
		// Open a notification that let the user to perform a checkin
		Intent checkInIntent = new Intent(SMApplication.getInstance(), CheckInActivity.class);

		int notifId = 1234;
		PendingIntent contentPI = PendingIntent.getActivity(SMApplication.getInstance(), notifId,
				checkInIntent, PendingIntent.FLAG_UPDATE_CURRENT);

		// Launch a notification
		NotificationController.getInstance().launchNotification(notifId,
				context.getString(R.string.alarm_title),
				context.getString(R.string.alarm_content),
				R.drawable.ic_launcher, contentPI);
	}

}

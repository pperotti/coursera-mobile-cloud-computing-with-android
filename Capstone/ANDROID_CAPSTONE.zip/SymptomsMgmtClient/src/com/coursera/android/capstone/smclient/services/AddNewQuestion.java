package com.coursera.android.capstone.smclient.services;

import java.util.ArrayList;
import java.util.Collection;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.QuestionController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Question;

public class AddNewQuestion implements Runnable {

	public static final String TAG = AddNewQuestion.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.ADD_QUESTION";

	public Intent mIntent;

	public AddNewQuestion(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			String questionText = mIntent.getStringExtra(BundleExtras.EXTRA_QUESTION_TEXT);
			ArrayList<String> answers = mIntent.getStringArrayListExtra(BundleExtras.EXTRA_QUESTION_ANSWERS);
			if (questionText!=null && answers != null && answers.size()>0) {
				Question question = new Question(questionText);
				question.addAnswers(answers);
				Collection<Question> questions = client.postQuestion(question);
				QuestionController.getInstance().setList(questions);
				
				OperationExecutorIntentService.broadcastResultOK(OPERATION);
			} else {
				OperationExecutorIntentService.broadcastResultError(OPERATION);
			}
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;
import java.util.Calendar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.model.CheckIn;

public class CheckInAdapter extends BaseAdapter {
	private ArrayList<CheckIn> mItems = new ArrayList<CheckIn>();

	private LayoutInflater mInflater;
	private ViewGroup mViewGroup = null;

	public CheckInAdapter(Context context) {
		mInflater = LayoutInflater.from(context);
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		if (convertView == null) {
			// Inflate
			convertView = mInflater.inflate(R.layout.checkin_list_item,
					mViewGroup);

			holder = new Holder();
			holder.date = (TextView) convertView.findViewById(R.id.tvCheckInDate);
			holder.time = (TextView) convertView.findViewById(R.id.tvCheckInTime);

			// Create a holder and save it for later usage
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}

		// Get the item
		CheckIn currentItem = mItems.get(position);

		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(Long.parseLong(currentItem.getTimestamp()));

		String dateFormat = "%d-%d-%d";
		String timeFormat = "%d:%d";

		String checkInDate = String.format(dateFormat,
				calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.MONTH)+1, calendar.get(Calendar.YEAR));
		String checkInTime = String.format(timeFormat,
				calendar.get(Calendar.HOUR_OF_DAY),
				calendar.get(Calendar.MINUTE));

		// Populate the items according to what was defined in the holder
		holder.date.setText(checkInDate);
		holder.time.setText(checkInTime);

		return convertView;
	}

	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		// Not needed for this scenario
		return 0;
	}

	public void setItems(ArrayList<CheckIn> items) {
		mItems = items;
	}

	// Holder for the UI items to be used in the list
	class Holder {
		TextView date;
		TextView time;
	}
}

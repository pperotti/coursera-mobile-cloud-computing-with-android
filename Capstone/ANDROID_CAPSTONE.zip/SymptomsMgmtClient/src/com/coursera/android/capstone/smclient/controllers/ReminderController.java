package com.coursera.android.capstone.smclient.controllers;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Reminder;
import com.coursera.android.capstone.smclient.receiver.AlarmReceiver;

public class ReminderController {

	private static ReminderController mInstance = new ReminderController();

	private Reminder mReminder;

	private SharedPreferences mStorage;

	private ReminderController() {
		mStorage = SMApplication.getInstance().getSharedPreferences(
				"ReminderSP", Activity.MODE_PRIVATE);

	}

	public static ReminderController getInstance() {
		return mInstance;
	}

	public ReminderController setReminder(Reminder reminder) {
		this.mReminder = reminder;

		// Configure Alarm Manager
		AlarmManager am = (AlarmManager) SMApplication.getInstance().getSystemService(Context.ALARM_SERVICE);
		long triggerAtMillis = getNextTriggerTime();
		long intervalMillis = reminder.getFrequency() * 1000 * 60 * 60;
		
		Intent intent = new Intent(SMApplication.getInstance(), AlarmReceiver.class);
		PendingIntent operation = PendingIntent.getBroadcast(SMApplication.getInstance(), 123, intent, PendingIntent.FLAG_UPDATE_CURRENT);
		am.setRepeating(AlarmManager.RTC_WAKEUP, triggerAtMillis, intervalMillis, operation);

		// Persist key values
		mStorage.edit()
				.putInt(BundleExtras.EXTRA_ALARM_FRECUENCY,
						reminder.getFrequency())
				.putString(BundleExtras.EXTRA_ALARM_MESSAGE,
						reminder.getMessage()).commit();

		return this;
	}
	
	//Each time the time is configured, the notification is reset
	private long getNextTriggerTime() {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(System.currentTimeMillis());
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		long nextStartTime = c.getTimeInMillis();
		return nextStartTime;
	}

	public Reminder getReminder() {
		return mReminder;
	}

}

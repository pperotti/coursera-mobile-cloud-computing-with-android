package com.coursera.android.capstone.smclient.extras;

public class BundleExtras {
	public static String EXTRA_PATIENT_ID = "patient_id";
	public static String EXTRA_CHECKIN = "checkin_entry";
	public static String EXTRA_MEDICINE_NAME = "medicine_name";
	public static String EXTRA_QUESTION_TEXT = "question_text";
	public static String EXTRA_QUESTION_ANSWERS = "question_answers";
	
	//Alarm-related extras
	public static String EXTRA_ALARM_FRECUENCY_IN_MILLIS = "alarm_frequency_in_millis";
	public static String EXTRA_ALARM_FRECUENCY = "alarm_frequency";
	public static String EXTRA_ALARM_MESSAGE = "alarm_check_in_message";
	
}

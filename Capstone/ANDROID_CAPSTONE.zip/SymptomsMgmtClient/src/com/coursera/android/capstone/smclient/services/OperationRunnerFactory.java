package com.coursera.android.capstone.smclient.services;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Obtain the actual runnable from the Intent.getAction()
 */
public class OperationRunnerFactory {

	public static final String TAG = OperationRunnerFactory.class.getSimpleName();
	
	public static Runnable createOperationRunner(Context context, Intent intent) {
		String operation = intent.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);
		Log.d(TAG, "OPERATION=>" + operation);
		Runnable selectedRunnable = null;
		if ( GetLogin.OPERATION.equals(operation)) {
			selectedRunnable = new GetLogin(intent);
		} else if (GetPatientList.OPERATION.equals(operation)) {
			selectedRunnable = new GetPatientList(intent);
		} else if (GetMedicineList.OPERATION.equals(operation)) {
			selectedRunnable = new GetMedicineList(intent);
		} else if (GetQuestionList.OPERATION.equals(operation)) {
			selectedRunnable = new GetQuestionList(intent);
		} else if (GetCheckInList.OPERATION.equals(operation)) {
			selectedRunnable = new GetCheckInList(intent);
		} else if (GetReminder.OPERATION.equals(operation)) {
			selectedRunnable = new GetReminder(intent);
		} else if (SyncDoctor.OPERATION.equals(operation)) {
			selectedRunnable = new SyncDoctor(intent);
		} else if (SyncPatient.OPERATION.equals(operation)) {
			selectedRunnable = new SyncPatient(intent);
		} else if (AddNewMedicine.OPERATION.equals(operation)) {
			selectedRunnable = new AddNewMedicine(intent);
		} else if (RemoveMedicine.OPERATION.equals(operation)) {
			selectedRunnable = new RemoveMedicine(intent);
		} else if (AddNewQuestion.OPERATION.equals(operation)) {
			selectedRunnable = new AddNewQuestion(intent);
		} else if (RemoveQuestion.OPERATION.equals(operation)) {
			selectedRunnable = new RemoveQuestion(intent);
		} else if (AddPatientMedicine.OPERATION.equals(operation)) {
			selectedRunnable = new AddPatientMedicine(intent);
		} else if (RemovePatientMedicine.OPERATION.equals(operation)) {
			selectedRunnable = new RemovePatientMedicine(intent);
		} else if (AddPatientQuestion.OPERATION.equals(operation)) {
			selectedRunnable = new AddPatientQuestion(intent);
		} else if (RemovePatientQuestion.OPERATION.equals(operation)) {
			selectedRunnable = new RemovePatientQuestion(intent);
		} else if (CollectStats.OPERATION.equals(operation)) {
			selectedRunnable = new CollectStats(intent);
		} else if (UpdateProfile.OPERATION.equals(operation)) {
			selectedRunnable = new UpdateProfile(intent);
		}
		return selectedRunnable;
	}
	
}

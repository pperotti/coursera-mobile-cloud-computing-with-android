package com.coursera.android.capstone.smclient.services;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Intent;
import android.util.Log;
import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.CheckInController;
import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.MedicineController;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.controllers.QuestionController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.CheckIn;
import com.coursera.android.capstone.smclient.model.Medicine;
import com.coursera.android.capstone.smclient.model.Patient;
import com.coursera.android.capstone.smclient.model.Profile;
import com.coursera.android.capstone.smclient.model.Question;
import com.coursera.android.capstone.smclient.model.Response;
import com.coursera.android.capstone.smclient.notifications.NotificationController;
import com.google.common.base.Objects;

public class SyncDoctor implements Runnable {

	public static final String TAG = SyncDoctor.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.SYNC_DOCTOR";

	public Intent mIntent;

	public SyncDoctor(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		Log.d(TAG, "SyncDoctor.run()");
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			
			String recordId = ProfileController.getInstance().getCurrentId();
			if ( recordId == null ) {
				//Die in peace
				return;
			}
			
			//Get the medicines related with that profile
			Collection<Medicine> medicines = client.getMedicines();
			MedicineController.getInstance().setList(medicines);
			
			//Get the custom questions related with that 
			List<Question> questions = client.getQuestions();
			QuestionController.getInstance().setList(questions);

			//Get an updated patient's list
			Collection<Patient> patients = client.getPatients(recordId);
			PatientController.getInstance().setList(patients).sortListByName();
			
			//TODO: If there are WARNINGs from the patient's data downloaded, then show a warning
			monitorPatientStatuses();
			
			OperationExecutorIntentService.broadcastResultOK(OPERATION);
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
	
	@SuppressLint("DefaultLocale")
	private void monitorPatientStatuses() {
		
		String monitoredQuestion = "How bad is your mouth pain/soar throat?".toLowerCase();
		long TWELVE_HOURS = 12 * 60 * 60 * 1000;
		long SIXTEEN_HOURS = 16 * 60 * 60 * 1000;
		
		List<Patient> patients = PatientController.getInstance().getList();
		for (Patient patient : patients) {
			List<CheckIn> checkIns = patient.getCheckIns();
			CheckInController.ReverseTimeComparator comparator = new CheckInController.ReverseTimeComparator(); 
			Collections.sort(checkIns, comparator);
			
			String lastConditionIdentified = null;
			long accumulatedTime = 0;
			boolean stopCheckInProcessing = false;
			
			for (CheckIn checkIn : checkIns ) {
				//Get the proper response
				List<Response> responses = checkIn.getResponses();
				for (Response response : responses) {
					if (monitoredQuestion.equals(response.getQuestionText().toLowerCase())) {

						//Evaluate the text replied
						String conditionIdentified = response.getAnswerText().toLowerCase();
						
						if (lastConditionIdentified == null) {
							//This is the evaluation for the first checkIn
							lastConditionIdentified = conditionIdentified;
						} else {
							//This is the evaluation for subsequent checkIns
							if (!lastConditionIdentified.equals(conditionIdentified)) {
								break;
							}
						}
						
						//Compare the time
						if ( accumulatedTime == 0) {
							accumulatedTime = System.currentTimeMillis() - Long.parseLong(checkIn.getTimestamp());
						} else { 
							long diff = System.currentTimeMillis() - Long.parseLong(checkIn.getTimestamp());
							accumulatedTime += diff;
						}
						
						//Evaluate the different conditions
						if ("severe".equals(lastConditionIdentified) && accumulatedTime > TWELVE_HOURS) {
							//Launch Notification
							launchNotificationForPatient(patient, "It's been more than 12 hours of severe pain!");
							stopCheckInProcessing = true;
						} else if ("moderate".equals(lastConditionIdentified) && accumulatedTime > SIXTEEN_HOURS) {
							//Launch Notification
							launchNotificationForPatient(patient, "It's been more than 16 hours of moderate pain!");
							stopCheckInProcessing = true;
						} else if ("can't eat".equals(lastConditionIdentified) && accumulatedTime > TWELVE_HOURS) {
							//Launch Notification
							launchNotificationForPatient(patient, "It's been more than 12 hours of being unable to eat");
							stopCheckInProcessing = true;
						}
						
						//Move to the next checkin evaluation
						break;
					}
				}
				
				if (stopCheckInProcessing) {
					break;
				}
			}
		}
	}
	
	private void launchNotificationForPatient(Patient patient, String content) {
		
		Profile profile = patient.getProfile();
		String title = "Warning for " + profile.getName() + " " + profile.getLastName();
		PendingIntent contentPI = null;
		
		int notifId = Objects.hashCode(patient.getProfile().getRecordId());
		
		NotificationController.getInstance().launchNotification(notifId, 
				title, 
				content, 
				R.drawable.ic_launcher, 
				contentPI);
	}
}

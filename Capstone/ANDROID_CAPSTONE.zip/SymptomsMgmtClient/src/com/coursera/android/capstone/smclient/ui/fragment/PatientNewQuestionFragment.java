package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.controllers.QuestionController;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Question;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.AddPatientQuestion;
import com.coursera.android.capstone.smclient.services.GetMedicineList;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;

public class PatientNewQuestionFragment extends Fragment {

	private static final String TAG = PatientNewQuestionFragment.class.getSimpleName();

	private OperationReceiver mOperationReceiver = new OperationReceiver();

	// UI Elements
	private ListView lvQuestionList;
	private PatientNewQuestionAdapter lvQuestionAdapter;
	private EditText etFilter;

	public PatientNewQuestionFragment() {
	}
	
	@Override
	public void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_patient_new_questions, container,
				false);

		lvQuestionList = (ListView) rootView.findViewById(android.R.id.list);
		lvQuestionAdapter = new PatientNewQuestionAdapter(getActivity());
		lvQuestionList.setAdapter(lvQuestionAdapter);
		lvQuestionList.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				//Pick a new question
				Question question = (Question) lvQuestionAdapter.getItem(position);
				Intent intent = OperationExecutorIntentService.createOperationIntent(SMApplication.getInstance(), AddPatientQuestion.OPERATION);				
				intent.putExtras(getArguments());
				intent.putExtra(BundleExtras.EXTRA_QUESTION_TEXT, question.getText());
				
				SMApplication.getInstance().startService(intent);
				
				//Go back to PatientQuestionFragment
				PatientQuestionFragment fragment = new PatientQuestionFragment();
				fragment.setArguments(getArguments());
				getFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).commit();
			}
		});

		etFilter = (EditText) rootView.findViewById(R.id.newQuestionSearchFilter);
		etFilter.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// Left in blank on purpose
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// Left in blank on purpose
			}

			@Override
			public void afterTextChanged(Editable s) {

				String text = etFilter.getText().toString();
				Log.i(TAG,
						"afterTextChanged=" + text + " count=" + text.length());

				if (text.length() == 0) {
					lvQuestionAdapter.restoreFilter();
				} else {
					lvQuestionAdapter.getFilter().filter(text);
				}

			}
		});

		
		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		ArrayList<Question> list = QuestionController.getInstance().getList();
		lvQuestionAdapter.setItems(list);
		lvQuestionAdapter.notifyDataSetChanged();
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mOperationReceiver);
	}
	
	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class OperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, TAG + " -> operation=" + operation);

			if (GetMedicineList.OPERATION.equals(operation)) {
				int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
						SMReceiver.RESULT_ERROR);
				if (SMReceiver.RESULT_OK == resultCode) {
					// OK - Update the adapter
				} else {
					// Error
					Toast.makeText(getActivity(), getString(R.string.error_on_get_patient_list), Toast.LENGTH_LONG).show();
				}
			}
		}
	}
}

package com.coursera.android.capstone.smclient.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;

/**
 * Receives the actions that are sent by different
 */
public class SMReceiver extends BroadcastReceiver {

	public static final String TAG = SMReceiver.class.getSimpleName();

	public static final String ACTION_POST_RESULT = "com.coursera.android.capstone.smclient.actions.ACTION_POST_RESULT";

	public static final String EXTRA_RESULT = "com.coursera.android.capstone.smclient.extras.RESULT";
	
	public static final int RESULT_OK = 0X0100;
	public static final int RESULT_ERROR = 0X0200;
	
	/**
	 * Category that must be used for Intents that are expected to be used from
	 * the GeneralReceiver
	 */
	public static final String CATEGORY_GENERAL = "com.coursera.android.capstone.smclient.category.general";

	public SMReceiver() {

	}

	@Override
	public void onReceive(Context context, Intent intent) {
		Log.e(TAG, "Action => " + intent.getAction());
	}

	// Create Intent Filter
	public static IntentFilter createListeningIntentFilter() {
		IntentFilter serviceIntentFilter = new IntentFilter();
		serviceIntentFilter.addAction(ACTION_POST_RESULT);
		serviceIntentFilter.addCategory(CATEGORY_GENERAL);
		return serviceIntentFilter;
	}

	// Create the intent to send the result back to the caller
	public static Intent createResultOperationIntent(String operation) {
		Intent newIntent = new Intent();
		newIntent.setAction(SMReceiver.ACTION_POST_RESULT);
		newIntent.putExtra(OperationExecutorIntentService.EXTRA_OPERATION, operation);
		newIntent.addCategory(CATEGORY_GENERAL);
		return newIntent;
	}
}

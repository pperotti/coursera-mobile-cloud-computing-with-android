package com.coursera.android.capstone.smclient.ui.fragment;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.GetLogin;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;

public class LoginFragment extends Fragment {

	private static final String TAG = LoginFragment.class.getSimpleName();

	/**
	 * All the actions that are triggered from this fragment
	 */
	public interface LoginActionListener {
		void onLoginCompleted(Intent intent);
		void onLoginError();
	}

	LoginActionListener mEmptyActionListener = new LoginActionListener() {
		@Override
		public void onLoginCompleted(Intent intent) {
			Log.d(TAG, "onLoginCompleted()");
		}

		@Override
		public void onLoginError() {
			Log.d(TAG, "onLoginError()");
		}
	};

	private LoginActionListener mLoginActionListener = mEmptyActionListener;
	private LoginOperationReceiver mLoginOperationReceiver = new LoginOperationReceiver();

	// UI Elements
	private Button mButtonNext;
	private EditText mUsername, mPassword;
	private RelativeLayout llDataEntry, llInProgressPanel;

	public LoginFragment() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_login, container,
				false);

		llDataEntry = (RelativeLayout) rootView.findViewById(R.id.llDataEntry);
		llInProgressPanel = (RelativeLayout) rootView
				.findViewById(R.id.llInProgressPanel);

		mUsername = (EditText) rootView.findViewById(R.id.etUsername);
		mPassword = (EditText) rootView.findViewById(R.id.etPassword);

		mButtonNext = (Button) rootView.findViewById(R.id.btNext);
		mButtonNext.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				String username = mUsername.getText().toString();
				String password = mPassword.getText().toString();

				if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
					Toast.makeText(getActivity(),
							getString(R.string.error_empty_fields),
							Toast.LENGTH_LONG).show();
					return;
				}

				llDataEntry.setVisibility(View.GONE);
				llInProgressPanel.setVisibility(View.VISIBLE);

				// Open the intent service
				Context context = SMApplication.getInstance();

				Intent intent = OperationExecutorIntentService
						.createOperationIntent(context, GetLogin.OPERATION);

				// Add the entered data from the UI and the missing one from
				// resources
				intent.putExtra(GetLogin.USERNAME, username);
				intent.putExtra(GetLogin.PASSWORD, password);
				intent.putExtra(GetLogin.CLIENT_ID,
						getString(R.string.connection_client_id));
				intent.putExtra(GetLogin.ENDPOINT,
						getString(R.string.connection_endpoint));

				// Init Service
				context.startService(intent);
			}
		});

		return rootView;
	}

	public void onStop() {
		super.onPause();

		mLoginActionListener = mEmptyActionListener;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		if (getActivity() instanceof LoginActionListener) {
			mLoginActionListener = (LoginActionListener) getActivity();
		} else {
			try {
				throw new IllegalAccessException("Not suitable container");
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mLoginOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mLoginOperationReceiver);
	}

	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class LoginOperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, "LoginOperationReceiver -> operation=" + operation);

			if (GetLogin.OPERATION.equals(operation)) {
				int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
						SMReceiver.RESULT_ERROR);
				if (SMReceiver.RESULT_OK == resultCode) {
					mLoginActionListener.onLoginCompleted(intent);
				} else {
					mLoginActionListener.onLoginError();
				}
			}

		}
	}

}

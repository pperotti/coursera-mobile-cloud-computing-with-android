package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Patient;
import com.coursera.android.capstone.smclient.model.Question;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.AddPatientQuestion;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;
import com.coursera.android.capstone.smclient.services.RemovePatientQuestion;

public class PatientQuestionFragment extends Fragment {

	private static final String TAG = PatientQuestionFragment.class.getSimpleName();

	private OperationReceiver mOperationReceiver = new OperationReceiver();

	// UI Elements
	private ListView lvQuestionList;
	private PatientQuestionAdapter lvQuestionAdapter;

	public PatientQuestionFragment() {
	}
	
	@Override
	public void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_medicines, container,
				false);

		lvQuestionList = (ListView) rootView.findViewById(android.R.id.list);
		lvQuestionAdapter = new PatientQuestionAdapter(getActivity(),getArguments());
		lvQuestionList.setAdapter(lvQuestionAdapter);

		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		refreshList();
		
		getActivity().getActionBar().setTitle(R.string.patient_questions_title);
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mOperationReceiver);
	}
	
	@Override
	public void onCreateOptionsMenu (Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		inflater.inflate(R.menu.patient_medicine_menu, menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		boolean retValue = true;
		
		switch ( item.getItemId() ) {
		case R.id.menu_add_new:
			PatientNewQuestionFragment patientNewQuestionFragment = new PatientNewQuestionFragment();
			patientNewQuestionFragment.setArguments(getArguments());
			getFragmentManager().beginTransaction().replace(R.id.content_frame, patientNewQuestionFragment).commit();
			break;
		case R.id.menu_done:
			PatientDetailsFragment fragment = new PatientDetailsFragment();
			fragment.setArguments(getArguments());
			getFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).commit();
		default:
			retValue = super.onOptionsItemSelected(item); 
		}
		
		return retValue;
	}


	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class OperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, TAG + " -> operation=" + operation);
			int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
					SMReceiver.RESULT_ERROR);
			if (AddPatientQuestion.OPERATION.equals(operation)) {
				if (SMReceiver.RESULT_OK == resultCode) {
					// OK - Update the adapter
					refreshList();
				} else {
					// Error
					Toast.makeText(getActivity(), getString(R.string.error_on_get_patient_list), Toast.LENGTH_LONG).show();
				}
			}
			else if (RemovePatientQuestion.OPERATION.equals(operation)) {
				if (SMReceiver.RESULT_OK == resultCode) {
					refreshList();
				} else {
					Toast.makeText(getActivity(), getString(R.string.error_on_get_patient_list), Toast.LENGTH_LONG).show();
				}
			}
		}
	}
	
	private void refreshList() {
		Bundle arguments = getArguments();
		String patientId = arguments.getString(BundleExtras.EXTRA_PATIENT_ID);
		Patient patient = PatientController.getInstance().getPatientById(patientId);
		
		ArrayList<Question> questionList = (ArrayList<Question>) patient.getQuestions();
		lvQuestionAdapter.setItems(questionList);
		lvQuestionAdapter.notifyDataSetChanged();
	}

}

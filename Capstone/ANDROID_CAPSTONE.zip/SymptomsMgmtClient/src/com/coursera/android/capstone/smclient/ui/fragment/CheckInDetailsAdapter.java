package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.model.Response;

public class CheckInDetailsAdapter extends BaseAdapter {
	
	private ArrayList<Response> mItems = new ArrayList<Response>();

	private LayoutInflater mInflater;
	private ViewGroup mViewGroup = null;

	public CheckInDetailsAdapter(Context context) {
		mInflater = LayoutInflater.from(context);
	}

	public View getView(final int position, View convertView, ViewGroup parent) {
		Holder holder = null;
		if (convertView == null) {
			// Inflate
			convertView = mInflater.inflate(R.layout.checkin_details_list_item,
					mViewGroup);

			holder = new Holder();
			holder.question = (TextView) convertView.findViewById(R.id.tvQuestion);
			holder.answer = (TextView) convertView.findViewById(R.id.tvAnswer);

			// Create a holder and save it for later usage
			convertView.setTag(holder);
		} else {
			holder = (Holder) convertView.getTag();
		}

		// Get the item
		Response currentItem = mItems.get(position);

		// Populate the items according to what was defined in the holder
		holder.question.setText(currentItem.getQuestionText());
		holder.answer.setText(currentItem.getAnswerText());

		return convertView;
	}

	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	public void setItems(ArrayList<Response> items) {
		mItems = items;
	}

	// Holder for the UI items to be used in the list
	class Holder {
		TextView question;
		TextView answer;
	}
}

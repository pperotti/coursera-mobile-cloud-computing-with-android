package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.CheckIn;
import com.coursera.android.capstone.smclient.model.Response;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.GetMedicineList;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;

public class PatientCheckInDetailsFragment extends Fragment {

	private static final String TAG = PatientCheckInDetailsFragment.class.getSimpleName();

	private OperationReceiver mOperationReceiver = new OperationReceiver();

	// UI Elements
	private ListView lvCheckInDetails;
	private CheckInDetailsAdapter lvCheckInDetailsAdapter;
	
	// The check in element
	private CheckIn mCheckIn;

	public PatientCheckInDetailsFragment() {
	}
	
	@Override
	public void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_checkinhistory, container,
				false);

		lvCheckInDetails = (ListView) rootView.findViewById(android.R.id.list);
		lvCheckInDetailsAdapter = new CheckInDetailsAdapter(getActivity());
		lvCheckInDetails.setAdapter(lvCheckInDetailsAdapter);
		lvCheckInDetails.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				//Get the proper answer
				Response response = (Response) lvCheckInDetailsAdapter.getItem(position);
				
				//Open the details
				PatientCheckInGraphDetailsFragment fragment = new PatientCheckInGraphDetailsFragment();
				
				Bundle arguments = new Bundle();
				arguments.putAll(getArguments());
				arguments.putString(BundleExtras.EXTRA_QUESTION_TEXT, response.getQuestionText());
				
				fragment.setArguments(arguments);
				getFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).commit();
				
			}
		});

		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		Bundle arguments = getArguments();
		String patientId = arguments.getString(BundleExtras.EXTRA_PATIENT_ID);
		int checkInPosition = arguments.getInt(BundleExtras.EXTRA_CHECKIN);
		
		mCheckIn = PatientController.getInstance().getPatientById(patientId).getCheckIns().get(checkInPosition);
		
		ArrayList<Response> list = (ArrayList<Response>) mCheckIn.getResponses();
		lvCheckInDetailsAdapter.setItems(list);
		lvCheckInDetailsAdapter.notifyDataSetChanged();
		
		getActivity().getActionBar().setTitle(R.string.patientcheckindetails_title);
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mOperationReceiver);
	}
	
	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class OperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, TAG + " -> operation=" + operation);

			if (GetMedicineList.OPERATION.equals(operation)) {
				int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
						SMReceiver.RESULT_ERROR);
				if (SMReceiver.RESULT_OK == resultCode) {
					// OK - Update the adapter
				} else {
					// Error
					Toast.makeText(getActivity(), getString(R.string.error_on_get_patient_list), Toast.LENGTH_LONG).show();
				}
			}
		}
	}
}

package com.coursera.android.capstone.smclient.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Represent custom question that a doctor can create for one or more patient.
 * 
 * One particular question will have more than possible answers.
 */
public class Question implements Comparable<Question>{

	private String text;

	private List<Answer> answers;
	
	public Question() {
		
	}
	
	public Question(String text) {
		this.text = text;
		this.answers = new ArrayList<Answer>();
	}
	
	public String getText() {
		return this.text;
	}
	
	public Question setText(String text) {
		this.text = text;
		return this;
	}
	
	public List<Answer> getAnswers() {
		return this.answers;
	}
	
	public Question addAnswer(Answer answer) {
		answers.add(answer);
		return this;
	}

	@Override
	public int compareTo(Question another) {
		return text.compareTo(another.getText());
	}
	
	public void addAnswers(ArrayList<String> answers) {
		Iterator<String> iterator = answers.iterator();
		while (iterator.hasNext()) {
			String newAnswerText = iterator.next();
			addAnswer(new Answer(newAnswerText));
		}
	}
}

package com.coursera.android.capstone.smclient.stats;

import java.util.HashMap;
import java.util.List;
import android.annotation.SuppressLint;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.model.CheckIn;
import com.coursera.android.capstone.smclient.model.Patient;
import com.coursera.android.capstone.smclient.model.Response;

public class StatsCollector {
	
	private static final StatsCollector mInstance = new StatsCollector();
	
	private HashMap<String, StatsResult> mResults = new HashMap<String, StatsResult>();
	
	private StatsCollector()  {
	}
	
	public static StatsCollector getInstance() {
		return mInstance;
	}
	
	@SuppressLint("DefaultLocale")
	public void collectStatsForPatientId(String patientId, String questionText) {
		StatsResult statsResult = new StatsResult();
		
		String lowercaseQuestionText = questionText.toLowerCase();
		
		Patient patient = PatientController.getInstance().getPatientById(patientId);
		if ( patient != null ) {
			
			//Get all checkins
			List<CheckIn> checkins = patient.getCheckIns();
			for(CheckIn checkIn : checkins) {
				List<Response> responses = checkIn.getResponses();
				for (Response response : responses) {
					if (response.getQuestionText().toLowerCase().equals(lowercaseQuestionText)) {
						statsResult.add(response.getAnswerText());
						break;
					}
				}
			}
		}
		statsResult.complete();
		mResults.put(patientId, statsResult);
	}

	public StatsResult getStatsResultForPatient(String patientId) {
		return mResults.get(patientId);
	}
}

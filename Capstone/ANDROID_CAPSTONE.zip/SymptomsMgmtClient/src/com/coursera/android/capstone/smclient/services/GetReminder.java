package com.coursera.android.capstone.smclient.services;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.controllers.ReminderController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.Reminder;

public class GetReminder implements Runnable {

	public static final String TAG = GetReminder.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.GET_REMINDER";

	public Intent mIntent;

	public GetReminder(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			
			String id = ProfileController.getInstance().getCurrentId();
			Reminder reminder = client.getPatientReminder(id);
			Log.i(TAG, "Frequency = " + reminder.getFrequency() + " Message=" + reminder.getMessage());
			ReminderController.getInstance().setReminder(reminder);
			OperationExecutorIntentService.broadcastResultOK(OPERATION);
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

package com.coursera.android.capstone.smclient.ui.fragment;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Patient;
import com.coursera.android.capstone.smclient.model.Profile;

public class PatientDetailsFragment extends Fragment {

	TextView tvFullName, tvBirthday, tvRecordId;
	Button btMedicine, btCheckInHistory, btQuestions;
	FragmentManager mFragmentManager;
	String dateFormat, patientDetailsBirthdayFormat;

	public PatientDetailsFragment() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_patient_details,
				container, false);

		tvFullName = (TextView) rootView.findViewById(R.id.tvFullName);
		tvBirthday = (TextView) rootView.findViewById(R.id.tvBirthday);
		tvRecordId = (TextView) rootView.findViewById(R.id.tvRecordId);

		btMedicine = (Button) rootView.findViewById(R.id.btMedicines);
		btMedicine.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Bundle arguments = getArguments();
				PatientMedicineFragment patientMedicineFragment = new PatientMedicineFragment();
				patientMedicineFragment.setArguments(arguments);
				mFragmentManager.beginTransaction().replace(R.id.content_frame, patientMedicineFragment).commit();
			}
		});

		btCheckInHistory = (Button) rootView
				.findViewById(R.id.btCheckInHistory);
		btCheckInHistory.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Bundle arguments = getArguments();
				PatientCheckInHistoryFragment checkHistoryFragment = new PatientCheckInHistoryFragment();
				checkHistoryFragment.setArguments(arguments);
				mFragmentManager.beginTransaction().replace(R.id.content_frame, checkHistoryFragment).commit();
			}
		});
		btQuestions = (Button) rootView.findViewById(R.id.btQuestions);
		btQuestions.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Bundle arguments = getArguments();
				PatientQuestionFragment patientQuestionFragment = new PatientQuestionFragment();
				patientQuestionFragment.setArguments(arguments);
				mFragmentManager.beginTransaction().replace(R.id.content_frame, patientQuestionFragment).commit();			}
		});

		patientDetailsBirthdayFormat = getString(R.string.patient_details_birthday_format);
		dateFormat = getString(R.string.date_format);
		
		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		mFragmentManager = getFragmentManager();

		Bundle arguments = getArguments();
		if (arguments.containsKey(BundleExtras.EXTRA_PATIENT_ID)) {
			String patientRecordId = arguments.getString(BundleExtras.EXTRA_PATIENT_ID);
			Patient patient = PatientController.getInstance().getPatientById(
					patientRecordId);
			Profile profile = patient.getProfile();
			String fullName = String.format(
					getString(R.string.text_fullname_format),
					profile.getName(), profile.getLastName());

			tvFullName.setText(fullName);
			String recId = String.format(
					getString(R.string.patient_details_record_id_format),
					profile.getRecordId());
			tvRecordId.setText(recId);
			tvBirthday.setText(String.format(patientDetailsBirthdayFormat,
					profile.getBirthDayAsText(dateFormat)));
		} else {
			getActivity().finish();
		}
		
		getActivity().getActionBar().setTitle(R.string.patient_details_title);
	}
}

package com.coursera.android.capstone.smclient.ui.activities;

import java.util.ArrayList;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.model.Profile;
import com.coursera.android.capstone.smclient.model.Role;
import com.coursera.android.capstone.smclient.sync.SyncHelper;
import com.coursera.android.capstone.smclient.ui.fragment.AboutFragment;
import com.coursera.android.capstone.smclient.ui.fragment.CheckInFragment;
import com.coursera.android.capstone.smclient.ui.fragment.ProfileFragment;
import com.coursera.android.capstone.smclient.ui.fragment.MedicinesFragment;
import com.coursera.android.capstone.smclient.ui.fragment.PatientsFragment;
import com.coursera.android.capstone.smclient.ui.fragment.QuestionsFragment;
import com.coursera.android.capstone.smclient.ui.fragment.RemindersFragment;

/**
 * Coordinate the flow between the fragments that are opened from the Home
 * screen.
 */
@SuppressWarnings("deprecation")
public class HomeActivity extends Activity {

	public static final String TAG = HomeActivity.class.getSimpleName();

	public static final int REQUEST_CODE_LOGIN_ACTIVITY = 0x1000;
	public static final String SELECTED_OPTION = "selected_option";

	private DrawerLayout mDrawerLayout;
	private ListView mDrawerList;
	private ArrayList<String> mDrawerOptions = new ArrayList<String>();
	private int[] mDrawerOptionKeys;
	private ActionBarDrawerToggle mDrawerToggle;
	private int mSelectedOptionPosition = -1;

	private CharSequence mDrawerTitle;
	private CharSequence mTitle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Log.d(TAG, "onCreate()");

		mTitle = mDrawerTitle = getTitle();
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerList = (ListView) findViewById(R.id.left_drawer);

		// set a custom shadow that overlays the main content when the drawer
		// opens
		mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
				GravityCompat.START);

		mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

		// enable ActionBar app icon to behave as action to toggle nav drawer
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setHomeButtonEnabled(true);

		// ActionBarDrawerToggle ties together the the proper interactions
		// between the sliding drawer and the action bar app icon
		mDrawerToggle = new ActionBarDrawerToggle(this, /* host Activity */
		mDrawerLayout, /* DrawerLayout object */
		R.drawable.ic_drawer, /* nav drawer image to replace 'Up' caret */
		R.string.drawer_open, /* "open drawer" description for accessibility */
		R.string.drawer_close /* "close drawer" description for accessibility */
		) {
			public void onDrawerClosed(View view) {
				getActionBar().setTitle(mTitle);
				invalidateOptionsMenu(); // creates call to
											// onPrepareOptionsMenu()
			}

			public void onDrawerOpened(View drawerView) {
				getActionBar().setTitle(mDrawerTitle);
				invalidateOptionsMenu(); // creates call to
											// onPrepareOptionsMenu()
			}
		};
		mDrawerLayout.setDrawerListener(mDrawerToggle);

		if (savedInstanceState == null) {
			mSelectedOptionPosition = -1;
		} else {
			mSelectedOptionPosition = savedInstanceState
					.getInt(SELECTED_OPTION);
		}

		Profile currentProfile = ProfileController.getInstance()
				.getCurrentProfile();
		if (currentProfile != null) {
			loadOptions(currentProfile);
		} else {
			requestLogin();
		}
		selectItem(mSelectedOptionPosition);
		
		//Create the sync account if it doesn't exists
		SyncHelper.createAccount(this);
	}

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);

		mDrawerToggle.syncState();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent intent) {

		Log.i(TAG, "onActivityResult()");

		if (REQUEST_CODE_LOGIN_ACTIVITY == requestCode) {
			if (Activity.RESULT_OK == resultCode) {
				Profile currentProfile = ProfileController.getInstance()
						.getCurrentProfile();
				if (currentProfile != null) {
					loadOptions(currentProfile);
					selectItem(0);
				}
			} else if (Activity.RESULT_CANCELED == resultCode) {
				finish();
			}
		}
	}

	private void loadOptions(Profile currentProfile) {
		if (currentProfile != null) {
			String role = currentProfile.getRole().getName();
			if (Role.ROLE_DOCTOR.equals(role)) {
				loadDoctorSelectionOptions();
			} else if (Role.ROLE_PATIENT.equals(role)) {
				loadPatientSelectionOptions();
			}
		}
	}

	private void requestLogin() {
		// Load the login fragment
		Intent intent = new Intent(this, LoginActivity.class);
		startActivityForResult(intent, REQUEST_CODE_LOGIN_ACTIVITY);
	}

	private void loadDoctorSelectionOptions() {
		mDrawerOptions.clear();
		mDrawerOptions.add(getString(R.string.key_patients));
		mDrawerOptions.add(getString(R.string.key_medicines));
		mDrawerOptions.add(getString(R.string.key_questions));
		mDrawerOptions.add(getString(R.string.key_profile));
		mDrawerOptions.add(getString(R.string.key_about));
		mDrawerOptions.add(getString(R.string.key_sign_out));

		mDrawerOptionKeys = new int[6];
		mDrawerOptionKeys[0] = R.string.key_patients;
		mDrawerOptionKeys[1] = R.string.key_medicines;
		mDrawerOptionKeys[2] = R.string.key_questions;
		mDrawerOptionKeys[3] = R.string.key_profile;
		mDrawerOptionKeys[4] = R.string.key_about;
		mDrawerOptionKeys[5] = R.string.key_sign_out;

		// set up the drawer's list view with items and click listener
		mDrawerList.setAdapter(new ArrayAdapter<String>(this,
				R.layout.drawer_list_item, mDrawerOptions));
	}

	private void loadPatientSelectionOptions() {
		mDrawerOptions.clear();
		mDrawerOptions.add(getString(R.string.key_checkin));
		mDrawerOptions.add(getString(R.string.key_reminders));
		mDrawerOptions.add(getString(R.string.key_profile));
		mDrawerOptions.add(getString(R.string.key_about));
		mDrawerOptions.add(getString(R.string.key_sign_out));

		mDrawerOptionKeys = new int[5];
		mDrawerOptionKeys[0] = R.string.key_checkin;
		mDrawerOptionKeys[1] = R.string.key_reminders;
		mDrawerOptionKeys[2] = R.string.key_profile;
		mDrawerOptionKeys[3] = R.string.key_about;
		mDrawerOptionKeys[4] = R.string.key_sign_out;

		// set up the drawer's list view with items and click listener
		mDrawerList.setAdapter(new ArrayAdapter<String>(this,
				R.layout.drawer_list_item, mDrawerOptions));

	}

	private void removeAllSelectionOptions() {
		mSelectedOptionPosition = -1;

		mDrawerOptions.clear();

		// set up the drawer's list view with items and click listener
		mDrawerList.setAdapter(new ArrayAdapter<String>(this,
				R.layout.drawer_list_item, mDrawerOptions));

		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerToggle.syncState();
	}

	private void selectItem(int position) {

		FragmentManager fragmentManager = getFragmentManager();

		if (position < 0 || mDrawerOptionKeys == null
				|| mDrawerOptionKeys.length < position) {
			setTitle(getString(R.string.app_name));
			mDrawerLayout.closeDrawer(mDrawerList);
			return;
		}

		mSelectedOptionPosition = position;
		int selectionPosition = mDrawerOptionKeys[position];

		switch (selectionPosition) {
		case R.string.key_checkin:
			fragmentManager.beginTransaction()
					.replace(R.id.content_frame, new CheckInFragment())
					.commit();
			break;
		case R.string.key_questions:
			fragmentManager.beginTransaction()
					.replace(R.id.content_frame, new QuestionsFragment())
					.commit();
			break;
		case R.string.key_reminders:
			fragmentManager.beginTransaction()
					.replace(R.id.content_frame, new RemindersFragment())
					.commit();
			break;
		case R.string.key_profile:
			fragmentManager.beginTransaction()
					.replace(R.id.content_frame, new ProfileFragment())
					.commit();
			break;
		case R.string.key_about:
			fragmentManager.beginTransaction()
					.replace(R.id.content_frame, new AboutFragment()).commit();
			break;
		case R.string.key_patients:
			fragmentManager.beginTransaction()
					.replace(R.id.content_frame, new PatientsFragment())
					.commit();
			break;
		case R.string.key_medicines:
			fragmentManager.beginTransaction()
					.replace(R.id.content_frame, new MedicinesFragment())
					.commit();
			break;
		case R.string.key_sign_out:
			fragmentManager
					.beginTransaction()
					.remove(fragmentManager
							.findFragmentById(R.id.content_frame)).commit();

			removeAllSelectionOptions();

			requestLogin();

			break;
		}

		// update selected item and title, then close the drawer
		if (mDrawerOptions.size() > 0) {
			mDrawerList.setItemChecked(position, true);
			setTitle(mDrawerOptions.get(position));
		} else {
			setTitle(getString(R.string.app_name));
		}
		mDrawerLayout.closeDrawer(mDrawerList);
	}

	@Override
	public void setTitle(CharSequence title) {
		mTitle = title;
		getActionBar().setTitle(mTitle);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// The action bar home/up action should open or close the drawer.
		// ActionBarDrawerToggle will take care of this.
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		// Handle action buttons
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);

		outState.putInt(SELECTED_OPTION, mSelectedOptionPosition);
	}

	private class DrawerItemClickListener implements
			ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			selectItem(position);
		}
	}
}

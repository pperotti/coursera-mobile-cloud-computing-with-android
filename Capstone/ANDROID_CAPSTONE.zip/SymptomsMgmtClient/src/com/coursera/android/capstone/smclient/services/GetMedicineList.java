package com.coursera.android.capstone.smclient.services;

import java.util.Collection;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.MedicineController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.Medicine;

public class GetMedicineList implements Runnable {

	public static final String TAG = GetMedicineList.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.GET_MEDICINE_LIST";

	public Intent mIntent;

	public GetMedicineList(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			Collection<Medicine> medicines = client.getMedicines();

			MedicineController.getInstance().setList(medicines); //.sortMedicineListByName();
			OperationExecutorIntentService.broadcastResultOK(OPERATION);
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

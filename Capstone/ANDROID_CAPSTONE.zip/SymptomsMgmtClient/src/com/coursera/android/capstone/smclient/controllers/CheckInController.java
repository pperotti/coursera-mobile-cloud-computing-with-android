package com.coursera.android.capstone.smclient.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.model.CheckIn;
import com.coursera.android.capstone.smclient.model.EnhancedCheckIn;
import com.coursera.android.capstone.smclient.persistance.CheckInStorage;
import com.coursera.android.capstone.smclient.sync.SyncHelper;

/**
 * Handle all the operations related with Checkin
 */
public class CheckInController {

	private static CheckInController mInstance = new CheckInController();

	private ArrayList<CheckIn> mList;

	private EnhancedCheckIn mTempCheckIn;
	private int mTempLastMedicineIndex;
	private int mTempLastQuestionIndex;

	public static CheckInController getInstance() {
		return mInstance;
	}

	public CheckInController setList(Collection<CheckIn> newList) {
		mList = new ArrayList<CheckIn>(newList);
		return this;
	}

	public ArrayList<CheckIn> getList() {
		return mList;
	}

	public CheckInController sortListByTime() {
		Collections.sort(mList, new TimeComparator());
		return this;
	}

	public CheckInController setTempCheckIn(EnhancedCheckIn checkIn) {
		mTempCheckIn = checkIn;
		return this;
	}

	public EnhancedCheckIn getTempCheckIn() {
		return mTempCheckIn;
	}

	/**
	 * Attempt to make perform the checkin. If fails, it will be later be SENT
	 * during next SYNC
	 */
	public void completeProcess() {

		Toast.makeText(SMApplication.getInstance(),
				SMApplication.getInstance().getString(R.string.checkin_thanks),
				Toast.LENGTH_LONG).show();

		// Ensure that the rawCheckIn has the proper timestamp
		mTempCheckIn.close();

		// Attempt to save it in the cloud
		CheckInStorage.getInstance().addCheckIn(mTempCheckIn.getRawCheckIn());

		// Ask the device to SYNC NOW
		SyncHelper.forceRefresh();
	}

	public CheckInController setLastTempMedicineIndex(int index) {
		mTempLastMedicineIndex = index;
		return this;
	}

	public int getLastTempMedicineIndex() {
		return mTempLastMedicineIndex;
	}

	public CheckInController setLastTempQuestionIndex(int index) {
		mTempLastQuestionIndex = index;
		return this;
	}

	public int getLastTempQuestionIndex() {
		return mTempLastQuestionIndex;
	}

	public CheckIn getCheckInByPosition(int position) {
		return mList.get(position);
	}

	// Add more method to ease the sorting to the consumers (evaluate set vs get
	// approach)
	public static class TimeComparator implements Comparator<CheckIn> {
		@Override
		public int compare(CheckIn lhs, CheckIn rhs) {
			return lhs.compareTo(rhs);
		}
	}

	// Add more method to ease the sorting to the consumers (evaluate set vs get
	// approach)
	public static class ReverseTimeComparator implements Comparator<CheckIn> {
		@Override
		public int compare(CheckIn lhs, CheckIn rhs) {
			return rhs.compareTo(lhs);
		}
	}

}

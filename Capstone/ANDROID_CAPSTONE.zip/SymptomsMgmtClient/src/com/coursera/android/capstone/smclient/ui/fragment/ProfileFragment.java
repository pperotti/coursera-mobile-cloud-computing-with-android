package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.Calendar;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.model.Profile;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;
import com.coursera.android.capstone.smclient.services.UpdateProfile;

public class ProfileFragment extends Fragment {

	public static final String TAG = ProfileFragment.class.getSimpleName();

	private OperationReceiver mOperationReceiver = new OperationReceiver();
	
	private EditText mName, mLastname, mRecordId;
	private DatePicker mBirthday;
	
	private Profile mProfileToUpdate;

	public ProfileFragment() {

	}

	@Override
	public void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setHasOptionsMenu(true);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_profile,
				container, false);

		mName = (EditText) rootView.findViewById(R.id.etName);
		mLastname = (EditText) rootView.findViewById(R.id.etLastName);
		mRecordId = (EditText) rootView.findViewById(R.id.etRecordId);
		mBirthday = (DatePicker) rootView.findViewById(R.id.dpProfileBirthday);
		
		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		populateProfileFields();
	}

	private void populateProfileFields() {
		Profile currentProfile = ProfileController.getInstance()
				.getCurrentProfile();
		String name = currentProfile.getName();
		String lastName = currentProfile.getLastName();
		String recordId = currentProfile.getRecordId();

		mName.setText((name != null) ? name : "");
		mLastname.setText((lastName != null) ? lastName : "");
		mRecordId.setText((recordId != null) ? recordId : "");
		
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(currentProfile.getBirthDay());
		
		mBirthday.init(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH), null);
	}
	
	@Override
	public void onCreateOptionsMenu (Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		
		inflater.inflate(R.menu.doctor_profile_menu, menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		boolean retValue = true;
		
		switch ( item.getItemId() ) {
		
		case R.id.menu_cancel:
			// Repopulate the profile with the original values
			populateProfileFields();
			break;
		case R.id.menu_done:
			
			String name = mName.getText().toString();
			String lastName = mLastname.getText().toString();
			
			if (TextUtils.isEmpty(name) || TextUtils.isEmpty(lastName)) {
				Toast.makeText(getActivity(), getString(R.string.error_empty_fields), Toast.LENGTH_LONG).show();
				return retValue;
			}
			
			// Attempt to make changes to the profile and save the results 
			mProfileToUpdate = ProfileController.getInstance().getNewProfileToUpdate();
			mProfileToUpdate.setName(name);
			mProfileToUpdate.setLastName(lastName);
			
			Calendar c = Calendar.getInstance();
			c.set(Calendar.DAY_OF_MONTH, mBirthday.getDayOfMonth());
			c.set(Calendar.MONTH, mBirthday.getMonth());
			c.set(Calendar.YEAR, mBirthday.getYear());
			
			mProfileToUpdate.setBirthDay(c.getTimeInMillis());
			
			ProfileController.getInstance().setProfileToUpdate(mProfileToUpdate);
			
			OperationExecutorIntentService.runServiceOperation(UpdateProfile.OPERATION);
			
			break;
		default:
			retValue = super.onOptionsItemSelected(item); 
		}
		
		return retValue;
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mOperationReceiver);
	}
	
	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class OperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, TAG + " -> operation=" + operation);

			if (UpdateProfile.OPERATION.equals(operation)) {
				int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
						SMReceiver.RESULT_ERROR);
				if (SMReceiver.RESULT_OK == resultCode) {
					// OK - Update the data
					populateProfileFields();
					Toast.makeText(getActivity(), getString(R.string.text_profile_updated), Toast.LENGTH_LONG).show();
				} else {
					// Error
					Toast.makeText(getActivity(), getString(R.string.error_on_updating_profile), Toast.LENGTH_LONG).show();
				}
			}
		}
	}

}

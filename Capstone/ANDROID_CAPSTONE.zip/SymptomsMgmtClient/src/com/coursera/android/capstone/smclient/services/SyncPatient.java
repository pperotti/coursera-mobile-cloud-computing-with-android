package com.coursera.android.capstone.smclient.services;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.CheckInController;
import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.MedicineController;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.controllers.QuestionController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.CheckIn;
import com.coursera.android.capstone.smclient.model.Medicine;
import com.coursera.android.capstone.smclient.model.Question;
import com.coursera.android.capstone.smclient.persistance.CheckInStorage;

public class SyncPatient implements Runnable {

	public static final String TAG = SyncPatient.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.SYNC_PATIENT";

	public Intent mIntent;

	public SyncPatient(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		Log.d(TAG, "SyncPatient.run()");
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			
			String patientId = ProfileController.getInstance().getCurrentId();
			if ( patientId == null ) {
				//Die in peace
				return;
			}
			
			//Get the medicines related with that profile
			List<Medicine> medicines = client.getPatientMedicines(patientId);
			MedicineController.getInstance().setList(medicines);
			
			//Get the custom questions related with that 
			List<Question> questions = client.getPatientQuestions(patientId);
			QuestionController.getInstance().setList(questions);

			//If there are pending data to send due to a pending check in, just send it
			Set<String> checkInKeys = CheckInStorage.getInstance().getCheckInKeys();
			Iterator<String> iterator = checkInKeys.iterator();
			while(iterator.hasNext()) {
				String key = iterator.next();
				CheckIn checkIn = CheckInStorage.getInstance().getCheckIn(key);
				
				//Send it
				try {
					client.postPatientCheckIn(patientId, checkIn);
				} catch ( Exception e ) {
					//If this cannot be sent, then this will be ignored.
				}
				
				//Remove it from storage if nothing fails
				CheckInStorage.getInstance().removeCheckIn(key);
			}
			
			//Refresh the checkin history
			Collection<CheckIn> checkInList = client.getPatientCheckIns(patientId);
			CheckInController.getInstance().setList(checkInList).sortListByTime();
			
			OperationExecutorIntentService.broadcastResultOK(OPERATION);
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

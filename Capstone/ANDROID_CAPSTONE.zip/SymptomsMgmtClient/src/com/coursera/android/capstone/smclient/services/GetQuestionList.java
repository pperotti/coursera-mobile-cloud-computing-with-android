package com.coursera.android.capstone.smclient.services;

import java.util.Collection;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.QuestionController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.Question;

public class GetQuestionList implements Runnable {

	public static final String TAG = GetQuestionList.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.GET_QUESTION_LIST";

	public Intent mIntent;

	public GetQuestionList(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			Collection<Question> questions = client.getQuestions();
			QuestionController.getInstance().setList(questions).sortListByName();
			OperationExecutorIntentService.broadcastResultOK(OPERATION);
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

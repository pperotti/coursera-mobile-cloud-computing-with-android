package com.coursera.android.capstone.smclient.sync;

import android.accounts.Account;
import android.content.AbstractThreadedSyncAdapter;
import android.content.ContentProviderClient;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SyncResult;
import android.os.Bundle;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.model.Profile;
import com.coursera.android.capstone.smclient.model.Role;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;
import com.coursera.android.capstone.smclient.services.SyncDoctor;
import com.coursera.android.capstone.smclient.services.SyncPatient;

/**
 * Handle the transfer of data between a server and an
 * app, using the Android sync adapter framework.
 */
public class SyncAdapter extends AbstractThreadedSyncAdapter {

	private static final String TAG = SyncAdapter.class.getSimpleName();
	
	// Global variables
    // Define a variable to contain a content resolver instance
    ContentResolver mContentResolver;
    /**
     * Set up the sync adapter
     */
    public SyncAdapter(Context context, boolean autoInitialize) {
        super(context, autoInitialize);
        /*
         * If your app uses a content resolver, get an instance of it
         * from the incoming Context
         */
        mContentResolver = context.getContentResolver();
    }

    /**
     * Set up the sync adapter. This form of the
     * constructor maintains compatibility with Android 3.0
     * and later platform versions
     */
    public SyncAdapter(
            Context context,
            boolean autoInitialize,
            boolean allowParallelSyncs) {
        super(context, autoInitialize, allowParallelSyncs);
        /*
         * If your app uses a content resolver, get an instance of it
         * from the incoming Context
         */
        mContentResolver = context.getContentResolver();
    }

	@Override
	public void onPerformSync(Account account, Bundle extras, String authority,
			ContentProviderClient provider, SyncResult syncResult) {

		Log.i(TAG, "onPerformSync()");
		
		//Check whether there is a valid account logged in
		Profile profile = ProfileController.getInstance().getCurrentProfile();
		if ( ProfileController.getInstance().getCurrentId() != null && profile != null ) {

			//Determine now whether the account is a patient or a doctor
			if ( Role.ROLE_DOCTOR.equals(profile.getRole().getName()) ) {
				Log.d(TAG, "Doctor's Sync!");
				
				//Download latest changes from the server and launch notification if there is a problem with a patient.
				OperationExecutorIntentService.runServiceOperation(SyncDoctor.OPERATION);
			} else if ( Role.ROLE_PATIENT.equals(profile.getRole().getName())) {
				Log.d(TAG, "Patient's Sync!");
				
				//If the account belongs to a patient, then try to download existing data and upload check in 
				OperationExecutorIntentService.runServiceOperation(SyncPatient.OPERATION);
			} else {
				// This is not a valid option
				Log.d(TAG, "Nothing to sync yet!");
			}
		} else {
			Log.d(TAG, "Nothing to sync because no one is logged in!");
		}
	}
}
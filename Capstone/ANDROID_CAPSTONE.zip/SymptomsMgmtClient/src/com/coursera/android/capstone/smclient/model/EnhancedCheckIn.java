package com.coursera.android.capstone.smclient.model;

import java.util.Calendar;
import java.util.List;

/**
 * CheckIn with extra handlers for date and time
 */
public class EnhancedCheckIn implements Comparable<EnhancedCheckIn> {

	private CheckIn rawCheckIn;
	private String date;
	private String time;
	private Calendar calendar;
	
	public EnhancedCheckIn() {
		rawCheckIn = new CheckIn();
		calendar = Calendar.getInstance();
	}
	
	public EnhancedCheckIn setTimestamp(String timestamp) {
		rawCheckIn.setTimestamp(timestamp);

		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(Long.parseLong(timestamp));
		date = calendar.get(Calendar.DAY_OF_WEEK_IN_MONTH) + "-" +
				calendar.get(Calendar.MONTH) + "-" + calendar.get(Calendar.YEAR);
		time = calendar.get(Calendar.HOUR_OF_DAY) + "-" +
				calendar.get(Calendar.MINUTE);
		
		return this;
	}
	
	public List<Response> getResponses() {
		return rawCheckIn.getResponses();
	}
	
	public void setResponses(List<Response> responses) {
		rawCheckIn.setResponses(responses);
	}
	
	public EnhancedCheckIn addResponse(Response response) {
		rawCheckIn.addResponse(response);
		return this;
	}
	
	public String getTimestamp() {
		return rawCheckIn.getTimestamp();
	}
	
	public String getDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(Long.parseLong(rawCheckIn.getTimestamp()));
		date = calendar.get(Calendar.DAY_OF_WEEK_IN_MONTH) + "-" +
				calendar.get(Calendar.MONTH) + "-" + calendar.get(Calendar.YEAR);
		return date;
	}
	
	public String getTime() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(Long.parseLong(rawCheckIn.getTimestamp()));
		time = calendar.get(Calendar.HOUR_OF_DAY) + "-" +
				calendar.get(Calendar.MINUTE);
		return time;
	}

	public EnhancedCheckIn setDate(int day, int mon, int year) {
		calendar.set(Calendar.DAY_OF_MONTH, day);
		calendar.set(Calendar.MONTH, mon);
		calendar.set(Calendar.YEAR, year);
		return this;
	}
	
	public EnhancedCheckIn setTime(int hour, int minute) {
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		return this;
	}

	public CheckIn getRawCheckIn() {
		return rawCheckIn;
	}
	
	public void close() {
		rawCheckIn.setTimestamp(String.valueOf(calendar.getTimeInMillis()));
	}
	
	@Override
	public int compareTo(EnhancedCheckIn another) {
		return rawCheckIn.getTimestamp().compareTo(another.getTimestamp());
	}
}


package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.CollectStats;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;
import com.coursera.android.capstone.smclient.stats.StatsCollector;
import com.coursera.android.capstone.smclient.stats.StatsResult;

public class PatientCheckInGraphDetailsFragment extends Fragment {

	private static final String TAG = PatientCheckInGraphDetailsFragment.class.getSimpleName();

	private OperationReceiver mOperationReceiver = new OperationReceiver();

	// UI Elements
	private ListView lvCheckInGraphDetails;
	private CheckInGraphDetailsAdapter lvCheckInGraphDetailsAdapter;

	public PatientCheckInGraphDetailsFragment() {
	}
	
	@Override
	public void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_checkinhistory, container,
				false);

		lvCheckInGraphDetails = (ListView) rootView.findViewById(android.R.id.list);
		lvCheckInGraphDetailsAdapter = new CheckInGraphDetailsAdapter(getActivity());
		lvCheckInGraphDetails.setAdapter(lvCheckInGraphDetailsAdapter);

		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		Intent intent = OperationExecutorIntentService.createOperationIntent(SMApplication.getInstance(), CollectStats.OPERATION);
		intent.putExtras(getArguments());
		SMApplication.getInstance().startService(intent);
		
		getActivity().getActionBar().setTitle(R.string.checkindetails_title);
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mOperationReceiver);
	}
	
	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class OperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, TAG + " -> operation=" + operation);

			if (CollectStats.OPERATION.equals(operation)) {
				int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
						SMReceiver.RESULT_ERROR);
				if (SMReceiver.RESULT_OK == resultCode) {
					// OK - Update the adapter
					
					String patientId = getArguments().getString(BundleExtras.EXTRA_PATIENT_ID);
					
					StatsResult statsResult = StatsCollector.getInstance().getStatsResultForPatient(patientId);
					ArrayList<StatsResult.StatsEntry> list = (ArrayList<StatsResult.StatsEntry>) statsResult.getExistingStatsEntries();
					lvCheckInGraphDetailsAdapter.setItems(list);
					lvCheckInGraphDetailsAdapter.setTotalResults(statsResult.getTotalResponses());
					lvCheckInGraphDetailsAdapter.notifyDataSetChanged();
					
				} else {
					// Error
					Toast.makeText(getActivity(), getString(R.string.error_on_getting_stats), Toast.LENGTH_LONG).show();
				}
			}
		}
	}
}

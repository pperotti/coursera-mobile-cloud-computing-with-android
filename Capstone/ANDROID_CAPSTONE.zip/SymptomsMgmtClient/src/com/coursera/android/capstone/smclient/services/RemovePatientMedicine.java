package com.coursera.android.capstone.smclient.services;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.model.Medicine;
import com.coursera.android.capstone.smclient.model.Patient;

public class RemovePatientMedicine implements Runnable {

	public static final String TAG = RemovePatientMedicine.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.REMOVE_PATIENT_MEDICINE";

	public Intent mIntent;

	public RemovePatientMedicine(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			String patientId = mIntent.getStringExtra(BundleExtras.EXTRA_PATIENT_ID);
			String medicineName = mIntent.getStringExtra(BundleExtras.EXTRA_MEDICINE_NAME);
			if (medicineName!=null && patientId != null ) {
				Medicine newMedicine = new Medicine(medicineName);
				Patient updatedPatient = client.deletePatientMedicine(patientId, newMedicine.getName());
				PatientController.getInstance().setPatientById(patientId, updatedPatient);
				
				OperationExecutorIntentService.broadcastResultOK(OPERATION);
			} else {
				OperationExecutorIntentService.broadcastResultError(OPERATION);
			}
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

package com.coursera.android.capstone.smclient.services;

import java.util.Collection;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.PatientController;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.Patient;

public class GetPatientList implements Runnable {

	public static final String TAG = GetPatientList.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.GET_PATIENT_LIST";

	public Intent mIntent;

	public GetPatientList(Intent intent) {
		mIntent = intent;
	}

	public void run() {

		String userId = ProfileController.getInstance().getCurrentId();
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();
			Collection<Patient> patients = client.getPatients(userId);
			PatientController.getInstance().setList(patients).sortListByName();
			OperationExecutorIntentService.broadcastResultOK(OPERATION);
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

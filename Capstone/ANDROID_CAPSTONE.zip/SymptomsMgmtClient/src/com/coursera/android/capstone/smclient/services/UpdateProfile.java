package com.coursera.android.capstone.smclient.services;

import android.content.Intent;
import android.util.Log;

import com.coursera.android.capstone.smclient.controllers.ConnectionController;
import com.coursera.android.capstone.smclient.controllers.ProfileController;
import com.coursera.android.capstone.smclient.controllers.SymptomMgmtApi;
import com.coursera.android.capstone.smclient.model.Profile;
import com.coursera.android.capstone.smclient.model.Role;

public class UpdateProfile implements Runnable {

	public static final String TAG = UpdateProfile.class.getSimpleName();

	public static final String OPERATION = "com.coursera.android.capstone.smclient.action.UPDATE_PROFILE";

	public Intent mIntent;

	public UpdateProfile(Intent intent) {
		mIntent = intent;
	}

	public void run() {
		try {
			SymptomMgmtApi client = ConnectionController.getInstance()
					.getClient();

			String currentId = ProfileController.getInstance().getCurrentId();
			Profile currentProfile = ProfileController.getInstance()
					.getCurrentProfile();
			if (currentProfile != null) {

				Profile profileToUpdate = ProfileController.getInstance()
						.getProfileToUpdate();
				if (profileToUpdate == null) {
					return;
				}

				Role role = currentProfile.getRole();
				Profile newProfile = null;
				if (Role.ROLE_DOCTOR.equals(role.getName())) {
					newProfile = client.postDoctorProfile(currentId, profileToUpdate).getProfile();
				} else {
					newProfile = client.postPatientProfile(currentId, profileToUpdate).getProfile();
				}
				ProfileController.getInstance().setProfileToUpdate(null).setCurrentProfile(currentId, newProfile);
				
			}
			OperationExecutorIntentService.broadcastResultOK(OPERATION);
		} catch (Exception e) {
			Log.e(TAG, e.getClass().getSimpleName() + " " + e.toString());
			OperationExecutorIntentService.broadcastResultError(OPERATION);
		}
	}
}

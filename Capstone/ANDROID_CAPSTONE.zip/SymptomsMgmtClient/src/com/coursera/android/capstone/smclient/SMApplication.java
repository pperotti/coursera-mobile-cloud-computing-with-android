package com.coursera.android.capstone.smclient;

import android.app.Application;
import android.support.v4.content.LocalBroadcastManager;

import com.coursera.android.capstone.smclient.receiver.SMReceiver;

/**
 * Custom SM Application
 */
public class SMApplication extends Application {

	private static SMApplication mInstance;

	@Override
	public void onCreate() {
		mInstance = this;

		LocalBroadcastManager.getInstance(this).registerReceiver(
				new SMReceiver(), SMReceiver.createListeningIntentFilter());
	}

	public static SMApplication getInstance() {
		return mInstance;
	}

}

package com.coursera.android.capstone.smclient.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import android.annotation.SuppressLint;

import com.coursera.android.capstone.smclient.model.Question;

/**
 * Handle all the operations related with Medicine
 */
public class QuestionController {

	private static QuestionController mInstance = new QuestionController();
	
	private ArrayList<Question> mList;
	
	public static QuestionController getInstance() {
		return mInstance;
	}
	
	public QuestionController setList(Collection<Question> newList) {
		mList = new ArrayList<Question>(newList);
		return this;
	}
	
	public ArrayList<Question> getList() {
		return mList;
	}

	public QuestionController sortListByName() {
		Collections.sort(mList, new AZComparator());
		return this;
	}

	@SuppressLint("DefaultLocale")
	public boolean contains(String questionText) {
		Iterator<Question> iterator = mList.iterator();
		questionText = questionText.toLowerCase();
		while (iterator.hasNext()) {
			if (iterator.next().getText().toLowerCase().equals(questionText)) {
				return true;
			}
		}
		return false;
	}
	
	@SuppressLint("DefaultLocale")
	public Question getQuestion(String questionText) {
		Iterator<Question> iterator = mList.iterator();
		questionText = questionText.toLowerCase();
		while (iterator.hasNext()) {
			Question question = iterator.next();
			if (question.getText().toLowerCase().equals(questionText)) {
				return question;
			}
		}
		return null;
	}
	
	//Add more method to ease the sorting to the consumers (evaluate set vs get approach)
	class AZComparator implements Comparator<Question> {

		@Override
		public int compare(Question lhs, Question rhs) {
			return lhs.compareTo(rhs);
		}
	}
	
}

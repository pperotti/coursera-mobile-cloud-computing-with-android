package com.coursera.android.capstone.smclient.ui.fragment;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.model.Question;

public class QuestionAdapter extends BaseAdapter
{
    private ArrayList<Question> mItems = new ArrayList<Question>();

    private LayoutInflater mInflater;
    private ViewGroup mViewGroup = null;
    
    public QuestionAdapter(Context context)
    {
        mInflater = LayoutInflater.from(context);
    }

    public View getView(final int position, View convertView, ViewGroup parent)
    {
        Holder holder = null;
        if (convertView == null)
        {
            // Inflate
            convertView = mInflater.inflate(R.layout.question_list_item, mViewGroup);

            holder = new Holder();
            holder.name = (TextView) convertView.findViewById(R.id.tvName);
            holder.remove = (ImageButton) convertView.findViewById(R.id.btRemove);

            // Create a holder and save it for later usage
            convertView.setTag(holder);
        } else
        {
            holder = (Holder) convertView.getTag();
        }

        // Get the item
        Question currentItem = mItems.get(position);

        // Populate the items according to what was defined in the holder
        holder.name.setText(currentItem.getText());
        holder.remove.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//Remove the present medicine from the repo through a command
			}
		});

        return convertView;
    }

    @Override
    public int getCount()
    {
        return mItems.size();
    }

    @Override
    public Object getItem(int position)
    {
        return mItems.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        // Not needed for this scenario
        return 0;
    }

    public void setItems(ArrayList<Question> items)
    {
        mItems = items;
    }
    
    // Holder for the UI items to be used in the list
    class Holder
    {
        TextView name;
        ImageButton remove;
    }
}



package com.coursera.android.capstone.smclient.model;

import java.util.ArrayList;

/**
 * Represent an active account for the Symptoms Management System. 
 */
public class SMAccount {
	
	public static String ROLE_DOCTOR = "doctor";
	public static String ROLE_PATIENT = "patient";

	private String mUsername;
	private String mRole;
	private ArrayList<String> mCategories;
	
	public String getUsername() {
		return mUsername;
	}
	
	public SMAccount setUsername(String username) {
		this.mUsername = username;
		return this;
	}
	
	public String getRole() {
		return mRole;
	}
	
	public SMAccount setRole(String role) {
		this.mRole = role;
		return this;
	}
	
	public ArrayList<String> getCategories() {
		return mCategories;
	}
	
	public SMAccount setCategories(ArrayList<String> categories) {
		this.mCategories = categories;
		return this;
	}
	
	//CHECK IF THE LAST TOKEN IS NEEDED
}

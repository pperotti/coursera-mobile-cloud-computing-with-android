package com.coursera.android.capstone.smclient.controllers;

import java.util.ArrayList;

import com.coursera.android.capstone.smclient.model.SMAccount;

/**
 * Handle the operations about the current accounts available for Symptoms
 * Management System.
 */
public class AccountController {

	private static final AccountController mAccountController = new AccountController();
	
	private ArrayList<SMAccount> mAccounts = new ArrayList<SMAccount>();
	
	private SMAccount mActiveAccount;
	
	private AccountController() {
		//Ensure that no one instance this class apart from the controller
	}
	
	/**
	 * @return The instance for the account controller. 
	 */
	public static AccountController getInstance() {
		return mAccountController;
	}
	
	/**
	 * Retrieve the existing accounts.
	 */
	public ArrayList<SMAccount> getAccounts() {
		return mAccounts;
	}
	
	/**
	 * Indicates whether there are available accounts in the app or not. 
	 */
	public boolean areAccountsAvailable() {
		return mAccounts.size() > 0;
	}
	
	/**
	 * Add a new account to the list of valid accounts
	 * 
	 * @param newAccount
	 */
	public void addAccount(SMAccount newAccount) {
		mAccounts.add(newAccount);
	}
	
	/**
	 * Set the new active account
	 */
	public void setActiveAccount(SMAccount smAccount) {
		this.mActiveAccount = smAccount;
	}
	
	/**
	 * Retrieve the current account in use 
	 * @return
	 */
	public SMAccount getActiveAccount() {
		return mActiveAccount;
	}
	
}

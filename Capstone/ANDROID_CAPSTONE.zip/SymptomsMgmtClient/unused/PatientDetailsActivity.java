package com.coursera.android.capstone.smclient.ui.activities;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.SMApplication;
import com.coursera.android.capstone.smclient.extras.BundleExtras;
import com.coursera.android.capstone.smclient.ui.fragment.PatientDetailsFragment;

public class PatientDetailsActivity extends Activity {

	public PatientDetailsActivity() {
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_patient_details);
		showMainFragment();
		
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setHomeButtonEnabled(true);

	}
	
	private void showMainFragment() {
		PatientDetailsFragment fragment = new PatientDetailsFragment();
		fragment.setArguments(getIntent().getExtras());
		getFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).commit();
	}
	
//	private void showMedicineFragment() {
//		PatientMedicineFragment fragment = new PatientMedicineFragment();
//		fragment.setArguments(getIntent().getExtras());
//		getFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).commit();
//	}

	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		int itemId = item.getItemId();
		switch (itemId) {
		case android.R.id.home:
			Fragment currentFragment = getFragmentManager().findFragmentById(
					R.id.content_frame);
			if (currentFragment instanceof PatientDetailsFragment ) {
				Log.d("PDA", "->PatientDetailsFragment");
				finish();
				return true;
//			} else if (currentFragment instanceof PatientMedicineFragment) {
//				Log.d("PDA", "->PatientDetailsFragment");
//				showMainFragment();
//				return true;
//			} else if (currentFragment instanceof PatientNewMedicineFragment ) {
//				Log.d("PDA", "->PatientNewMedicineFragment");
//				showMedicineFragment();
//				return true;
//			} else if (currentFragment instanceof PatientQuestionFragment) {
//				Log.d("PDA", "->PatientQuestionFragment");
//				showMainFragment();
//				return true;
//			} else if (currentFragment instanceof PatientNewQuestionFragment ) {
//				Log.d("PDA", "->PatientNewQuestionFragment");
//				showMedicineFragment();
//				return true;	
			} else {
				Log.d("PDA", "->ELSE");
				return false;
			}
		}
		return super.onMenuItemSelected(featureId, item);
	}

	public static Intent createPatientDetailsActivityIntent(String patientId) {
		Intent intent = new Intent(SMApplication.getInstance(),
				PatientDetailsActivity.class);
		intent.putExtra(BundleExtras.EXTRA_PATIENT_ID, patientId);
		return intent;
	}

}

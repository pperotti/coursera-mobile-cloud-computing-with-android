package com.coursera.android.capstone.smclient.services;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

public class ActionExecutorIntentService extends IntentService {

	private static final String TAG = ActionExecutorIntentService.class.getSimpleName();
	
	// Constants for the Thread Pool
	private static final int CORE_POOL_SIZE = 2;
	private static final int MAXIMUM_CORE_SIZE = 4;
	private static final int TIMEOUT = 10;

	private static ThreadPoolExecutor mExecutorPool = new ThreadPoolExecutor(
			CORE_POOL_SIZE, MAXIMUM_CORE_SIZE, TIMEOUT, TimeUnit.SECONDS,
			new ArrayBlockingQueue<Runnable>(2),
			Executors.defaultThreadFactory());

	public ActionExecutorIntentService() {
		super("ActionExecutorIntentService");
	}

	public ActionExecutorIntentService(String name) {
		super(name);
	}

	@Override
	protected void onHandleIntent(final Intent intent) {
		Log.i(TAG, "ActionExecutorIntentService onHandleIntent=>" + intent.getAction());
		Runnable newTask = ActionFactory.createAction(getApplicationContext(),
				intent);
		if (newTask != null) {
			mExecutorPool.execute(newTask);
		}
	}

	@Override
	public void onDestroy() {
		
		Log.i(TAG, "ActionExecutorIntentService onHandleIntent=>" + intent.getAction());
		
		mExecutorPool.shutdown();
	}

}

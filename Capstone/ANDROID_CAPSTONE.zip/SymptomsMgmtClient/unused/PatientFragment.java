package com.coursera.android.capstone.smclient.ui.fragment;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.coursera.android.capstone.smclient.R;
import com.coursera.android.capstone.smclient.receiver.SMReceiver;
import com.coursera.android.capstone.smclient.services.GetPatientList;
import com.coursera.android.capstone.smclient.services.OperationExecutorIntentService;

public class PatientFragment extends Fragment {

	private static final String TAG = PatientFragment.class.getSimpleName();

//	private interface PatientActionListener {
//	}
//
//	private PatientActionListener mEmptyPatientListener = new PatientActionListener() {
//	};
//
//	private PatientActionListener mPatientActionListener = mEmptyPatientListener;

	private PatientOperationReceiver mPatientOperationReceiver = new PatientOperationReceiver();

	// UI Elements
	private ListView lvPatientList;
	private PatientAdapter lvPatientAdapter;

	public PatientFragment() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment_login, container,
				false);

		lvPatientList = (ListView) rootView.findViewById(android.R.id.list);
		lvPatientAdapter = new PatientAdapter(getActivity());
		lvPatientList.setAdapter(lvPatientAdapter);

		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
//		if (getActivity() instanceof PatientActionListener) {
//			mPatientActionListener = (PatientActionListener) getActivity();
//		} else {
//			try {
//				throw new IllegalAccessException("Not suitable container");
//			} catch (IllegalAccessException e) {
//				e.printStackTrace();
//			}
//		}
	}

	@Override
	public void onResume() {
		super.onResume();

		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.registerReceiver(mPatientOperationReceiver,
						SMReceiver.createListeningIntentFilter());
	}

	@Override
	public void onPause() {
		super.onPause();
		LocalBroadcastManager
				.getInstance(getActivity().getApplicationContext())
				.unregisterReceiver(mPatientOperationReceiver);
	}

	/**
	 * Receives the actions relevant for this UI piece.
	 */
	class PatientOperationReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {

			String operation = intent
					.getStringExtra(OperationExecutorIntentService.EXTRA_OPERATION);

			Log.d(TAG, "LoginOperationReceiver -> operation=" + operation);

			if (GetPatientList.OPERATION.equals(operation)) {
				int resultCode = intent.getIntExtra(SMReceiver.EXTRA_RESULT,
						SMReceiver.RESULT_ERROR);
				if (SMReceiver.RESULT_OK == resultCode) {
					
					// OK - Update the adapter
					
				} else {

					// Error
					
				}
			}
		}
	}

}

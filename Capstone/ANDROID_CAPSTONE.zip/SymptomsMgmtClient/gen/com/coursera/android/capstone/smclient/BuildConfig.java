/** Automatically generated file. DO NOT MODIFY */
package com.coursera.android.capstone.smclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
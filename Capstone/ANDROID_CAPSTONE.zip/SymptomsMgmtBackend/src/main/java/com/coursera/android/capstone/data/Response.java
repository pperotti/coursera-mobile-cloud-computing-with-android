package com.coursera.android.capstone.data;

/**
 * Contains the data about the response to a single question. 
 * 
 * The reason why the actual text is created instead of question/answers pairs 
 * is just to avoid depending on such objects over time since both of them can change. So 
 * it is important to save what the actual user replied.  
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 */
public class Response {

	private String questionText;
	private String answerText;
	
	public Response() {
		//Left in blank on purpose
	}
	
	public Response(String questionText, String answerText) {
		this.questionText = questionText;
		this.answerText = answerText;
	}
	
	public String getQuestionText() {
		return this.questionText;
	}
	
	public String getAnswerText() {
		return this.answerText;
	}
	
	public Response setAnswerText(String answerText) {
		this.answerText = answerText;
		return this;
	}
	
	public Response setQuestionText(String questionText) {
		this.questionText = questionText;
		return this;
	}
}

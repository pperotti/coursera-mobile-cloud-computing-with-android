package com.coursera.android.capstone.data;

/**
 * Represent a single medicine.
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 */
public class Medicine {

	private String name;

	public Medicine() {
		//This is left in blank on purpose 
	}
	
	public Medicine(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public Medicine setName(String name) {
		this.name = name;
		return this;
	}
	
}

package com.coursera.android.capstone.data;

public class Answer {
	
	private String answerText;
	
	public Answer() {
	}
	
	public Answer(String text) {
		this.answerText = text;
	}
	
	public String getAnswerText() {
		return this.answerText;
	}
	
	public Answer setAnswerText(String text) {
		this.answerText = text;
		return this;
	}
}

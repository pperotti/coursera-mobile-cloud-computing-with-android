package com.coursera.android.capstone.data;

/**
 * Reminder's configuration
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 */
public class Reminder {

	String reminderId;
	
	// Determine how often the reminder will be presented
	int frequency;
	
	// Determine which ring tone is expected to be used for the path
	String ringtonePath;
	
	// Determine the message that will be presented to the user when the alarm is presented.
	String message;
	
	public Reminder() {
		this.reminderId = String.format("%f", Math.random());
	}
	
	public int getFrequency() {
		return this.frequency;
	}
	
	public Reminder setFrequency(int frequency) {
		this.frequency = frequency;
		return this;
	}
	
	public String getRingtonePath() {
		return this.ringtonePath;
	}
	
	public Reminder setRingtonePath(String ringtonePath) {
		this.ringtonePath = ringtonePath;
		return this;
	}
	
	public String getMessage() {
		return this.message;
	}
	
	public Reminder setMessage(String message) {
		this.message = message;
		return this;
	}
	
	public String getReminderId() {
		return this.reminderId;
	}
	
	public Reminder setReminderId(String reminderId) {
		this.reminderId = reminderId;
		return this;
	}
}

/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package com.coursera.android.capstone;

import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.coursera.android.capstone.client.SymptomMgmtApi;
import com.coursera.android.capstone.data.About;
import com.coursera.android.capstone.data.Answer;
import com.coursera.android.capstone.data.CheckIn;
import com.coursera.android.capstone.data.Doctor;
import com.coursera.android.capstone.data.Medicine;
import com.coursera.android.capstone.data.Patient;
import com.coursera.android.capstone.data.Profile;
import com.coursera.android.capstone.data.Question;
import com.coursera.android.capstone.data.Reminder;
import com.coursera.android.capstone.data.Response;
import com.coursera.android.capstone.data.Role;

@Controller
public class SymptomsMgmtController {

	// Patient's list
	HashMap<String, Patient> mPatients;

	// Doctor's list
	HashMap<String, Doctor> mDoctors;

	// Medicine's list
	HashMap<String, Medicine> mMedicines;

	// Custom Question's list
	HashMap<String, Question> mQuestions;

	public SymptomsMgmtController() {
		mPatients = new HashMap<String, Patient>();
		mDoctors = new HashMap<String, Doctor>();
		mMedicines = new HashMap<String, Medicine>();
		mQuestions = new HashMap<String, Question>();

		//initData();
		initRealData();
	}

	private void initRealData() {

		// Set up questions
		Question q1 = new Question("How bad is your mouth pain/soar throat?")
				.addAnswer(new Answer("Well-controlled"))
				.addAnswer(new Answer("Moderate"))
				.addAnswer(new Answer("Severe"));

		Question q2 = new Question("Did your medicine stop you from eating?")
				.addAnswer(new Answer("No")).addAnswer(new Answer("Some"))
				.addAnswer(new Answer("I can't eat"));

		Question q3 = new Question(
				"How are you feeling today compared with yesterday?")
				.addAnswer(new Answer("Much better"))
				.addAnswer(new Answer("Little better"))
				.addAnswer(new Answer("Worst"));

		Question q4 = new Question("How often you present symptoms yesterday?")
				.addAnswer(new Answer("I didn't"))
				.addAnswer(new Answer("Twice a day"))
				.addAnswer(new Answer("From time to time"))
				.addAnswer(new Answer("All the time"));

		mQuestions.put(q1.getText(), q1);
		mQuestions.put(q2.getText(), q2);
		mQuestions.put(q3.getText(), q3);
		mQuestions.put(q4.getText(), q4);
		
		// Set up medicines
		Medicine m1 = new Medicine("Lortab");
		mMedicines.put(m1.getName(), m1);
		Medicine m2 = new Medicine("OxyContin");
		mMedicines.put(m2.getName(), m2);
		Medicine m3 = new Medicine("Coricidin HBP oral");
		mMedicines.put(m3.getName(), m3);
		Medicine m4 = new Medicine("Nite-Time oral");
		mMedicines.put(m4.getName(), m4);

		// Doctors
		Profile p1 = new Profile().setName("Patch").setLastName("Adams")
				.setRecordId("A00000000001").setEmail("patch.adams@gmail.com")
				.setBirthDay(getDate(1,11,1961))
				.setRole(new Role().setName(Role.ROLE_DOCTOR));
		Doctor d1 = new Doctor(p1);
		mDoctors.put(p1.getRecordId(), d1);

		Profile p2 = new Profile().setName("Buddy").setLastName("Rydell")
				.setRecordId("A00000000002").setEmail("buddy.rydell@gmail.com")
				.setBirthDay(getDate(1,12,1960))				
				.setRole(new Role().setName(Role.ROLE_DOCTOR));
		Doctor d2 = new Doctor(p2);
		mDoctors.put(p2.getRecordId(), d2);

		// Patients for Doctor 1
		addPatient("Michael", "Scott", "B00000000001", getDate(5,5,1978), new Question[]{q1, q2, q3}, new Medicine[]{m1, m2, m3}, d1 );
		addPatient("Pam", "Beesly", "B00000000002", getDate(5,5,1979), new Question[]{q1, q2, q3}, new Medicine[]{m1, m2, m3}, d1 );
		addPatient("Jim", "Halpert", "B00000000003", getDate(5,5,1980), new Question[]{q1, q2, q3}, new Medicine[]{m1, m2, m3}, d1 );
		addPatient("Dwight", "Schrute", "B00000000004", getDate(5,5,1981), new Question[]{q1, q2, q4}, new Medicine[]{m1, m2, m4}, d1 );
		addPatient("Andy", "Bernard", "B00000000005", getDate(5,5,1982), new Question[]{q1, q2, q4}, new Medicine[]{m1, m2, m4}, d1 );
		// Patients for Doctor 2		
		addPatient("Ross", "Geller", "B00000000006", getDate(6,1,1980), new Question[]{q1, q2, q3}, new Medicine[]{m1, m2}, d2 );
		addPatient("Monica", "Geller", "B00000000007", getDate(6,2,1980), new Question[]{q1, q2, q3}, new Medicine[]{m1, m2}, d2 );
		addPatient("Chandler", "Bing", "B00000000008", getDate(6,3,1980), new Question[]{q1, q2, q3}, new Medicine[]{m1, m2, m3}, d2 );
		addPatient("Joey", "Tribbiani", "B00000000009", getDate(6,4,1980), new Question[]{q1, q2, q4}, new Medicine[]{m1, m2, m4}, d2 );
		addPatient("Rachael", "Green", "B00000000010", getDate(6,5,1980), new Question[]{q1, q2, q4}, new Medicine[]{m1, m2}, d2 );
		addPatient("Phoebe", "Buffay", "B00000000011", getDate(6,6,1980), new Question[]{q1, q2, q3}, new Medicine[]{m1, m2}, d2 );
		
		//Question to monitor
		String questionText = "How bad is your mouth pain/soar throat?";
		long twentyHoursAgo = 20 * 60 * 60 * 1000;
		
		//Add some check-in history for each different scenario to be warned
		Patient michaelScott = mPatients.get("B00000000001");
		
		CheckIn ci = new CheckIn();
		ci.addResponse(new Response().setAnswerText("Severe").setQuestionText(questionText));
		ci.setTimestamp(String.valueOf(System.currentTimeMillis()-twentyHoursAgo));
		michaelScott.addCheckIn(ci);
		
		Patient pamBeesly = mPatients.get("B00000000002");
		ci = new CheckIn();
		ci.addResponse(new Response().setAnswerText("Moderate").setQuestionText(questionText));
		ci.setTimestamp(String.valueOf(System.currentTimeMillis()-twentyHoursAgo));
		pamBeesly.addCheckIn(ci);
		
		Patient jimHalpert = mPatients.get("B00000000003");
		ci = new CheckIn();
		ci.addResponse(new Response().setAnswerText("Can't eat").setQuestionText(questionText));
		ci.setTimestamp(String.valueOf(System.currentTimeMillis()-twentyHoursAgo));
		jimHalpert.addCheckIn(ci);
	}
	
	private long getDate(int day, int month, int year) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, day);
		cal.set(Calendar.MONTH, month-1);
		cal.set(Calendar.YEAR, year);
		
		return cal.getTimeInMillis(); 
	}

	private void addPatient(String name, String lastName, String id, long birthDay, Question[] questions, Medicine[] medicines, Doctor doctor) {
		Profile profile = new Profile().setName(name)
				.setLastName(lastName).setRecordId(id)
				.setEmail(name + "." + lastName + "@gmail.com")
				.setBirthDay(birthDay)
				.setRole(new Role().setName(Role.ROLE_PATIENT));
		Patient patient = new Patient(profile);

		Reminder reminder = new Reminder().setFrequency(6).setMessage(
				"It's checkin time!");

		// Add a reminder for the patient
		patient.setReminder(reminder);

		// Add questions
		for ( int i=0;i<questions.length;i++)
			patient.addQuestion(questions[i]);

		// Add meds
		for ( int i=0;i<medicines.length;i++)
			patient.addMedicine(medicines[i]);
	
		// Add the patient to the data base
		mPatients.put(profile.getRecordId(), patient);
		
		// Associate doctor and patient
		doctor.addPatient(patient);
	}

	/**
	 * Init Test data and the relation ships
	 */
	private void initTestData() {

		mPatients = new HashMap<String, Patient>();
		mDoctors = new HashMap<String, Doctor>();
		mMedicines = new HashMap<String, Medicine>();
		mQuestions = new HashMap<String, Question>();

		// Add custom questions to the common list
		for (int i = 1; i < 7; i++) {
			Question q = new Question("Custom Questions " + i);
			for (int j = 1; j < 4; j++) {
				q.addAnswer(new Answer("Answer " + j));
			}
			mQuestions.put(q.getText(), q);
		}

		// Create doctors
		for (int i = 1; i <= 2; i++) {
			Profile profile = new Profile().setName("D" + i + " Name")
					.setLastName("D" + i + " Lastname")
					.setRecordId("A0000000000" + i)
					.setEmail("d" + i + "@gmail.com")
					.setRole(new Role().setName(Role.ROLE_DOCTOR));
			Doctor doctor = new Doctor(profile);
			mDoctors.put(profile.getRecordId(), doctor);
		}

		Object[] doctors = mDoctors.values().toArray();

		// Create all patients data
		for (int i = 1, doctorPosition = 0; i <= 10; i++) {
			
			Calendar birthday = Calendar.getInstance();
			birthday.set(Calendar.DAY_OF_MONTH, 24);
			birthday.set(Calendar.MONTH, 10);
			birthday.set(Calendar.YEAR, 1978);
			
			Profile profile = new Profile().setName("P" + i + " Name")
					.setLastName("P" + i + " Lastname")
					.setRecordId("B0000000000" + i)
					.setEmail("p" + i + "@gmail.com")
					.setBirthDay(birthday.getTimeInMillis())
					.setRole(new Role().setName(Role.ROLE_PATIENT));
			Patient patient = new Patient(profile);

			Reminder reminder = new Reminder().setFrequency(4).setMessage(
					"It's checkin time!");

			// Add a reminder for the patient
			patient.setReminder(reminder);

			Iterator<String> iterator = mQuestions.keySet().iterator();
			while (iterator.hasNext()) {
				Question question = mQuestions.get(iterator.next());
				patient.addQuestion(question);
			}

			// ADd responses to a check-in
			patient.addCheckIn(new CheckIn().setTimestamp(
					String.valueOf(12345678L)).addResponse(
					new Response("Question", "Response")));

			// Add the patient to the data base
			mPatients.put(profile.getRecordId(), patient);

			// Associate each patient to a random doctor
			Doctor doctor = (Doctor) doctors[doctorPosition];
			doctor.addPatient(patient);

			if (i == 4) {
				doctorPosition++;
			}
		}

		// Create Default Medicines
		Medicine m1 = new Medicine("m1");
		mMedicines.put(m1.getName(), m1);
		Medicine m2 = new Medicine("m2");
		mMedicines.put(m2.getName(), m2);
		Medicine m3 = new Medicine("m3");
		mMedicines.put(m3.getName(), m3);

		// Associate medicines to patients
		Iterator<String> patientList = mPatients.keySet().iterator();
		while (patientList.hasNext()) {
			Patient patient = mPatients.get(patientList.next());
			patient.addMedicine(m1).addMedicine(m2).addMedicine(m3);
		}
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_ABOUT, method = RequestMethod.GET)
	public @ResponseBody About getAbout() {
		return new About("Symptoms Management - Android Capstone Rocks!");
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_DOCTOR + "/{id}"
			+ SymptomMgmtApi.PATH_PATIENT, method = RequestMethod.GET)
	public @ResponseBody Collection<Patient> getPatients(
			@PathVariable("id") String id, HttpServletResponse response) {

		Doctor doctor = null;
		if (id != null && id.length() > 0) {
			doctor = mDoctors.get(id);
			if (doctor != null) {
				return doctor.getPatients();
			} else {
				response.setStatus(404);
			}
		}

		return mPatients.values();
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_PROFILE, method = RequestMethod.GET)
	public @ResponseBody Profile getPatientProfile(
			@PathVariable("id") String id, HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.getProfile();
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_DOCTOR + "/{id}"
			+ SymptomMgmtApi.PATH_PROFILE, method = RequestMethod.GET)
	public @ResponseBody Profile getDoctorProfile(
			@PathVariable("id") String id, HttpServletResponse response) {

		Doctor doctor = null;
		if (id != null && id.length() > 0) {
			doctor = mDoctors.get(id);
			if (doctor != null) {
				return doctor.getProfile();
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_REMINDER, method = RequestMethod.GET)
	public @ResponseBody Reminder getPatientReminder(
			@PathVariable("id") String id, HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.getReminder();
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_MEDICINE, method = RequestMethod.GET)
	public @ResponseBody List<Medicine> getPatientMedicines(
			@PathVariable("id") String id, HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.getMedicines();
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_MEDICINE, method = RequestMethod.GET)
	public @ResponseBody Collection<Medicine> getMedicines(
			HttpServletResponse response) {
		return mMedicines.values();
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_QUESTION, method = RequestMethod.GET)
	public @ResponseBody Collection<Question> getQuestions(
			HttpServletResponse response) {
		return mQuestions.values();
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_QUESTION, method = RequestMethod.GET)
	public @ResponseBody List<Question> getPatientQuestions(
			@PathVariable("id") String id, HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.getQuestions();
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_CHECKIN, method = RequestMethod.GET)
	public @ResponseBody Collection<CheckIn> getPatientCheckIns(
			@PathVariable("id") String id, HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.getCheckIns();
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_CHECKIN + "/{checkInId}"
			+ SymptomMgmtApi.PATH_RESPONSE, method = RequestMethod.GET)
	public @ResponseBody List<Response> getPatientCheckInResponses(
			@PathVariable("id") String patientId,
			@PathVariable("checkInId") String checkInId,
			HttpServletResponse response) {

		Patient patient = null;
		if (patientId != null && patientId.length() > 0) {
			patient = mPatients.get(patientId);
			if (patient != null) {
				CheckIn checkIn = patient.getCheckIn(checkInId);
				if (checkIn != null) {
					return checkIn.getResponses();
				}
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_INITTESTDATA, method = RequestMethod.POST)
	public @ResponseBody boolean postInitTestData() {
		initTestData();
		return Boolean.TRUE;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_PROFILE, method = RequestMethod.POST)
	public @ResponseBody Patient postPatientProfile(
			@PathVariable("id") String id, @RequestBody Profile profile,
			HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				patient.setProfile(profile);
				return patient;
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_DOCTOR + "/{id}"
			+ SymptomMgmtApi.PATH_PROFILE, method = RequestMethod.POST)
	public @ResponseBody Doctor postDoctorProfile(
			@PathVariable("id") String id, @RequestBody Profile profile,
			HttpServletResponse response) {

		Doctor doctor = null;
		if (id != null && id.length() > 0) {
			doctor = mDoctors.get(id);
			if (doctor != null) {
				doctor.setProfile(profile);
				return doctor;
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_CHECKIN, method = RequestMethod.POST)
	public @ResponseBody Patient postPatientCheckIn(
			@PathVariable("id") String id, @RequestBody CheckIn checkin,
			HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.addCheckIn(checkin);
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_REMINDER, method = RequestMethod.POST)
	public @ResponseBody Patient postPatientReminder(
			@PathVariable("id") String id, @RequestBody Reminder reminder,
			HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.setReminder(reminder);
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_MEDICINE, method = RequestMethod.POST)
	public @ResponseBody Patient postPatientMedicine(
			@PathVariable("id") String id, @RequestBody Medicine medicine,
			HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.addMedicine(medicine);
			} else {
				response.setStatus(404);
			}
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_MEDICINE, method = RequestMethod.POST)
	public @ResponseBody Collection<Medicine> postMedicine(
			@RequestBody Medicine medicine, HttpServletResponse response) {

		if (medicine != null && medicine.getName() != null) {
			mMedicines.put(medicine.getName(), medicine);
			return mMedicines.values();
		} else {
			response.setStatus(400);
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_MEDICINE + "/{id}", method = RequestMethod.DELETE)
	public @ResponseBody Collection<Medicine> deleteMedicine(
			@PathVariable("id") String id, HttpServletResponse response) {
		if (mMedicines.containsKey(id)) {
			mMedicines.remove(id);
			return mMedicines.values();
		} else {
			response.setStatus(404);
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_MEDICINE + "/{medicineId}", method = RequestMethod.DELETE)
	public @ResponseBody Patient deletePatientMedicine(
			@PathVariable("id") String id,
			@PathVariable("medicineId") String medicineId,
			HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				Medicine medicine = mMedicines.get(medicineId);
				if (medicine != null) {
					return patient.removeMedicine(medicine);
				}
			}
		}
		response.setStatus(404);

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_QUESTION, method = RequestMethod.POST)
	public @ResponseBody Collection<Question> postQuestion(
			@RequestBody Question question, HttpServletResponse response) {

		if (question != null && question.getText() != null) {
			mQuestions.put(question.getText(), question);
			return mQuestions.values();
		} else {
			response.setStatus(400);
		}
		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_QUESTION, method = RequestMethod.POST)
	public @ResponseBody Patient postPatientQuestion(
			@PathVariable("id") String id, @RequestBody Question question,
			HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.addQuestion(question);
			}
		}
		response.setStatus(404);

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_QUESTION + "/{id}", method = RequestMethod.DELETE)
	public @ResponseBody Collection<Question> deleteQuestion(
			@PathVariable("id") String id, HttpServletResponse response) {
		if (mQuestions.containsKey(id)) {
			mQuestions.remove(id);
			return mQuestions.values();
		} else {
			response.setStatus(404);
		}

		return null;
	}

	@RequestMapping(value = SymptomMgmtApi.PATH_PATIENT + "/{id}"
			+ SymptomMgmtApi.PATH_QUESTION + "/{questionId}", method = RequestMethod.DELETE)
	public @ResponseBody Patient deletePatientQuestion(
			@PathVariable("id") String id,
			@PathVariable("questionId") String questionId,
			HttpServletResponse response) {

		Patient patient = null;
		if (id != null && id.length() > 0) {
			patient = mPatients.get(id);
			if (patient != null) {
				return patient.removeQuestion(new Question(questionId));
			}
		}
		response.setStatus(404);

		return null;
	}

	
	@RequestMapping(value = SymptomMgmtApi.PATH_ROLE + "/{id}", method = RequestMethod.GET)
	public @ResponseBody Role getRole(@PathVariable("id") String id,
			HttpServletResponse response) {

		if (id != null) {
			Profile profile = null;

			if (mPatients.containsKey(id)) {
				Patient patient = mPatients.get(id);
				profile = patient.getProfile();
			} else if (mDoctors.containsKey(id)) {
				Doctor doctor = mDoctors.get(id);
				profile = doctor.getProfile();
			}

			System.out.println("PROFILE => " + profile + " ID=" + id);

			// Get the role if there is a profile for the specified id
			if (profile != null && profile.getRole() != null) {
				return profile.getRole();
			}
		}
		response.setStatus(404);
		return null;

	}

}

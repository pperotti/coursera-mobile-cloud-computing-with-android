package com.coursera.android.capstone.data;


/**
 * 
 * @author Pablo Perotti (pablo.perotti@gmail.com)
 *
 */
public class Profile {

	String recordId;
	String name;
	String lastName;
	String email;
	//Date birthDay;
	long birthDay;
	Role role;

	public Profile() {
	}
	
	public String getRecordId() {
		return this.recordId;
	}
	
	public Profile setRecordId(String recordId) {
		this.recordId = recordId;
		return this;
	}

	public String getName() {
		return this.name;
	}

	public Profile setName(String name) {
		this.name = name;
		return this;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public Profile setLastName(String lastName) {
		this.lastName = lastName;
		return this;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public Profile setEmail(String email) {
		this.email = email;
		return this;
	}
	
	public long getBirthDay() {
		return this.birthDay;
	}
	
	public Profile setBirthDay(long birthDay) {
		this.birthDay = birthDay;
		return this;
	}
	
	public Profile setRole(Role role) {
		this.role = role;
		return this;
	}
	
	public Role getRole() {
		return this.role;
	}
}

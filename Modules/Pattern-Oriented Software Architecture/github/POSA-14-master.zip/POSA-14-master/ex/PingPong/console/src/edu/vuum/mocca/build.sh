#/bin/sh -f
javac ConsolePlatformStrategy.java Main.java Options.java PlayPingPong.java PlatformStrategy.java PlatformStrategyFactory.java



